:HL["/_next/static/chunks/b654e941df076cdf.css","style"]
0:{"buildId":"e32gd9GfR34HdiKJb7ogY","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
