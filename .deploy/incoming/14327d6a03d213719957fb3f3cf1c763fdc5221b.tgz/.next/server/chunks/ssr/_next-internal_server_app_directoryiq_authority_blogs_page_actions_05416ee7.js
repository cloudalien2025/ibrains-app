module.exports=[92863,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_directoryiq_authority_blogs_page_actions_05416ee7.js.map