module.exports=[97743,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_directoryiq_authority_page_actions_1cf453f3.js.map