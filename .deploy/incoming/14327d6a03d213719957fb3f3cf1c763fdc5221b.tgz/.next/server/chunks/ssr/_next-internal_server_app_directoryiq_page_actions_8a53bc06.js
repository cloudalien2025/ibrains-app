module.exports=[31867,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_directoryiq_page_actions_8a53bc06.js.map