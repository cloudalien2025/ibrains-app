module.exports=[99660,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_directoryiq_versions_page_actions_3ec1cb30.js.map