module.exports=[83110,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_directoryiq_authority_listings_page_actions_87987fdb.js.map