module.exports=[68882,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_directoryiq_settings_page_actions_0938aef8.js.map