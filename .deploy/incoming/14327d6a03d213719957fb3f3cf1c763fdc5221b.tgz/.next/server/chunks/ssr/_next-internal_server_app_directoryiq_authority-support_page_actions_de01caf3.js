module.exports=[34995,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_directoryiq_authority-support_page_actions_de01caf3.js.map