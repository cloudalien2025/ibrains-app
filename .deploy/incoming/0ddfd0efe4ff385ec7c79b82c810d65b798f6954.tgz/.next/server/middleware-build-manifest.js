globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/72e142f30eb8f380.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/f2f58a7e93290fbb.js",
    "static/chunks/7bff2d0adf880ba2.js",
    "static/chunks/turbopack-77869d255ace7f3b.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];