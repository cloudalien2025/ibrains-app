:HL["/_next/static/chunks/a5646ef69d5ce816.css","style"]
0:{"buildId":"zZICSmrmSrE7Tpg65ZE8v","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
