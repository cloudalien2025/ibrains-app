var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/runs/[runId]/route.js")
R.c("server/chunks/[root-of-the-server]__c4825f8f._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_runs_[runId]_route_actions_4507c282.js")
R.m(24020)
module.exports=R.m(24020).exports
