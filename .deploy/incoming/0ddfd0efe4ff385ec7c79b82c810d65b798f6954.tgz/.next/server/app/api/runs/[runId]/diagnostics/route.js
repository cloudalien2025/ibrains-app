var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/runs/[runId]/diagnostics/route.js")
R.c("server/chunks/[root-of-the-server]__21e9827b._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_runs_[runId]_diagnostics_route_actions_08976aa8.js")
R.m(4807)
module.exports=R.m(4807).exports
