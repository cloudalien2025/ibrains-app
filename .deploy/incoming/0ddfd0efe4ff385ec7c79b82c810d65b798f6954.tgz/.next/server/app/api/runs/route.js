var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/runs/route.js")
R.c("server/chunks/[root-of-the-server]__ffdf9768._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_runs_route_actions_43b80d25.js")
R.m(6106)
module.exports=R.m(6106).exports
