var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/meta/release/route.js")
R.c("server/chunks/[root-of-the-server]__ebd8338c._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_meta_release_route_actions_296529af.js")
R.m(27897)
module.exports=R.m(27897).exports
