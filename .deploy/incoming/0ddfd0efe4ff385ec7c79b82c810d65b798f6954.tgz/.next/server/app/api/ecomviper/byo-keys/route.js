var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ecomviper/byo-keys/route.js")
R.c("server/chunks/[root-of-the-server]__cc1d5dee._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_ecomviper_byo-keys_route_actions_06c56678.js")
R.m(9336)
module.exports=R.m(9336).exports
