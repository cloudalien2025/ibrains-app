var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ecomviper/snapshot/route.js")
R.c("server/chunks/[root-of-the-server]__a96820d3._.js")
R.c("server/chunks/[root-of-the-server]__7478415b._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/_a3f7064b._.js")
R.c("server/chunks/_next-internal_server_app_api_ecomviper_snapshot_route_actions_ca454703.js")
R.m(13202)
module.exports=R.m(13202).exports
