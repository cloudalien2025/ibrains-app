var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/authority/listings/route.js")
R.c("server/chunks/[root-of-the-server]__ab192203._.js")
R.c("server/chunks/src_directoryiq_69398f6e._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/ce889_server_app_api_directoryiq_authority_listings_route_actions_1a179c48.js")
R.m(85197)
module.exports=R.m(85197).exports
