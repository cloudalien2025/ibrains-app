var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/authority/ingest/blogs/route.js")
R.c("server/chunks/[root-of-the-server]__6619367a._.js")
R.c("server/chunks/[root-of-the-server]__42661674._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/src_directoryiq_69398f6e._.js")
R.c("server/chunks/ce889_server_app_api_directoryiq_authority_ingest_blogs_route_actions_8b47326b.js")
R.m(6879)
module.exports=R.m(6879).exports
