var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/blog-drafts/[draft_id]/preview/route.js")
R.c("server/chunks/[root-of-the-server]__c4952ce8._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/bec2d_app_api_directoryiq_blog-drafts_[draft_id]_preview_route_actions_2e3cc936.js")
R.m(88778)
module.exports=R.m(88778).exports
