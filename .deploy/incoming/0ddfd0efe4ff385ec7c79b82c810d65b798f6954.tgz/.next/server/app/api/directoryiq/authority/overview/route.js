var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/authority/overview/route.js")
R.c("server/chunks/[root-of-the-server]__289af77a._.js")
R.c("server/chunks/src_directoryiq_69398f6e._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/ce889_server_app_api_directoryiq_authority_overview_route_actions_b1d0aefe.js")
R.m(98514)
module.exports=R.m(98514).exports
