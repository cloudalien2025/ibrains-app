var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__6619367a._.js")
R.c("server/chunks/_a3f7064b._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/[root-of-the-server]__e4045687._.js")
R.c("server/chunks/_next-internal_server_app_api_directoryiq_dashboard_route_actions_06d7c25c.js")
R.m(28496)
module.exports=R.m(28496).exports
