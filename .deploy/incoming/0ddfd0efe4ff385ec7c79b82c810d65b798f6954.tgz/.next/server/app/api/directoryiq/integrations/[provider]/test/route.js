var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/integrations/[provider]/test/route.js")
R.c("server/chunks/[root-of-the-server]__760a6ae9._.js")
R.c("server/chunks/[root-of-the-server]__6619367a._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/ce889_server_app_api_directoryiq_integrations_[provider]_test_route_actions_c302e96c.js")
R.m(38482)
module.exports=R.m(38482).exports
