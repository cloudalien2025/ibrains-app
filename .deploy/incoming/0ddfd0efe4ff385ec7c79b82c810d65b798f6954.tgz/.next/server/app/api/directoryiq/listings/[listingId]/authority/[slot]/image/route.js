var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/listings/[listingId]/authority/[slot]/image/route.js")
R.c("server/chunks/[root-of-the-server]__6619367a._.js")
R.c("server/chunks/_27d38ea4._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/[root-of-the-server]__c9e342a3._.js")
R.c("server/chunks/1a58a_directoryiq_listings_[listingId]_authority_[slot]_image_route_actions_2003f29b.js")
R.m(17775)
module.exports=R.m(17775).exports
