var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/snapshot/route.js")
R.c("server/chunks/[root-of-the-server]__427d6d2e._.js")
R.c("server/chunks/[root-of-the-server]__7478415b._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/_a3f7064b._.js")
R.c("server/chunks/_next-internal_server_app_api_directoryiq_snapshot_route_actions_a911cf0e.js")
R.m(18841)
module.exports=R.m(18841).exports
