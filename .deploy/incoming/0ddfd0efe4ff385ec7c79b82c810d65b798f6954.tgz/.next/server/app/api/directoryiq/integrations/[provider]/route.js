var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/integrations/[provider]/route.js")
R.c("server/chunks/[root-of-the-server]__94f098a9._.js")
R.c("server/chunks/[root-of-the-server]__6619367a._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/ce889_server_app_api_directoryiq_integrations_[provider]_route_actions_449751dd.js")
R.m(88799)
module.exports=R.m(88799).exports
