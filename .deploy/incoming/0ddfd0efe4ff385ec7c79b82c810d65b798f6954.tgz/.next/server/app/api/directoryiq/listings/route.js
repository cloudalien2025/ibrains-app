var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/listings/route.js")
R.c("server/chunks/[root-of-the-server]__6619367a._.js")
R.c("server/chunks/[root-of-the-server]__3721c6ae._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/_next-internal_server_app_api_directoryiq_listings_route_actions_fee1c527.js")
R.m(1285)
module.exports=R.m(1285).exports
