var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/blog-drafts/generate/route.js")
R.c("server/chunks/[root-of-the-server]__358d6e1a._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/ce889_server_app_api_directoryiq_blog-drafts_generate_route_actions_4b537624.js")
R.m(35588)
module.exports=R.m(35588).exports
