var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/connect/route.js")
R.c("server/chunks/[root-of-the-server]__9558bac8._.js")
R.c("server/chunks/[root-of-the-server]__6619367a._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/_a3f7064b._.js")
R.c("server/chunks/_next-internal_server_app_api_directoryiq_connect_route_actions_dede0668.js")
R.m(32222)
module.exports=R.m(32222).exports
