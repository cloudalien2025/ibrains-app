var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/listings/[listingId]/route.js")
R.c("server/chunks/[root-of-the-server]__6619367a._.js")
R.c("server/chunks/[root-of-the-server]__fc1780b6._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/ce889_server_app_api_directoryiq_listings_[listingId]_route_actions_1180d9c3.js")
R.m(75047)
module.exports=R.m(75047).exports
