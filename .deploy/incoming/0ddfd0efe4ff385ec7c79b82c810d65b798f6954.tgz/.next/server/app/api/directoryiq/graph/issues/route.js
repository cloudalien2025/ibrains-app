var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/graph/issues/route.js")
R.c("server/chunks/[root-of-the-server]__a036efa7._.js")
R.c("server/chunks/src_directoryiq_69398f6e._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_directoryiq_graph_issues_route_actions_fabe8a06.js")
R.m(31923)
module.exports=R.m(31923).exports
