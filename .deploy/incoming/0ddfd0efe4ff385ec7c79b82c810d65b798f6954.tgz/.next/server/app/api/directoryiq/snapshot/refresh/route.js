var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/snapshot/refresh/route.js")
R.c("server/chunks/[root-of-the-server]__e6090df1._.js")
R.c("server/chunks/[root-of-the-server]__7478415b._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/_a3f7064b._.js")
R.c("server/chunks/ce889_server_app_api_directoryiq_snapshot_refresh_route_actions_2f41121c.js")
R.m(57286)
module.exports=R.m(57286).exports
