var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/authority-support/serp-outline/status/route.js")
R.c("server/chunks/[root-of-the-server]__50d82787._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/3e585_api_directoryiq_authority-support_serp-outline_status_route_actions_6d20373a.js")
R.m(16778)
module.exports=R.m(16778).exports
