var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/listings/[listingId]/upgrade/push/route.js")
R.c("server/chunks/_6399e167._.js")
R.c("server/chunks/[root-of-the-server]__d638f324._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/bec2d_app_api_directoryiq_listings_[listingId]_upgrade_push_route_actions_02bbda40.js")
R.m(42488)
module.exports=R.m(42488).exports
