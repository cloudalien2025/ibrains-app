var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/listings/[listingId]/authority/[slot]/draft/route.js")
R.c("server/chunks/[root-of-the-server]__6619367a._.js")
R.c("server/chunks/_27d38ea4._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/[root-of-the-server]__3505b757._.js")
R.c("server/chunks/1a58a_directoryiq_listings_[listingId]_authority_[slot]_draft_route_actions_2fff9ce7.js")
R.m(33842)
module.exports=R.m(33842).exports
