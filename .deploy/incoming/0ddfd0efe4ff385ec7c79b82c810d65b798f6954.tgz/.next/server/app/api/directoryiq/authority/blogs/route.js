var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/authority/blogs/route.js")
R.c("server/chunks/[root-of-the-server]__780ba89b._.js")
R.c("server/chunks/src_directoryiq_69398f6e._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_directoryiq_authority_blogs_route_actions_ac613525.js")
R.m(63600)
module.exports=R.m(63600).exports
