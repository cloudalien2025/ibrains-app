var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/integrations/route.js")
R.c("server/chunks/[root-of-the-server]__9fc917e2._.js")
R.c("server/chunks/[root-of-the-server]__6619367a._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/_next-internal_server_app_api_directoryiq_integrations_route_actions_9c5bef4c.js")
R.m(78198)
module.exports=R.m(78198).exports
