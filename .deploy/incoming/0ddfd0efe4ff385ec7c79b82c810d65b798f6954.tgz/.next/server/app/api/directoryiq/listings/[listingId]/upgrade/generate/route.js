var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/listings/[listingId]/upgrade/generate/route.js")
R.c("server/chunks/_6399e167._.js")
R.c("server/chunks/[root-of-the-server]__406a3d9b._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/3e585_api_directoryiq_listings_[listingId]_upgrade_generate_route_actions_48f186c2.js")
R.m(73834)
module.exports=R.m(73834).exports
