var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/directoryiq/graph/rebuild/route.js")
R.c("server/chunks/[root-of-the-server]__0e53ca7a._.js")
R.c("server/chunks/src_directoryiq_69398f6e._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_directoryiq_graph_rebuild_route_actions_10663dfe.js")
R.m(57031)
module.exports=R.m(57031).exports
