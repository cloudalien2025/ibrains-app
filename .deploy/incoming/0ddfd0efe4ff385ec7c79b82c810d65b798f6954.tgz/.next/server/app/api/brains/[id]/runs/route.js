var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/brains/[id]/runs/route.js")
R.c("server/chunks/[root-of-the-server]__c58d91cf._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_brains_[id]_runs_route_actions_ac29b645.js")
R.m(33957)
module.exports=R.m(33957).exports
