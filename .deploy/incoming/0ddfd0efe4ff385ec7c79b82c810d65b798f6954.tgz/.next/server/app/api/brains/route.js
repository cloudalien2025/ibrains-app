var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/brains/route.js")
R.c("server/chunks/[root-of-the-server]__9dc3a5f4._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_brains_route_actions_473ff63d.js")
R.m(62092)
module.exports=R.m(62092).exports
