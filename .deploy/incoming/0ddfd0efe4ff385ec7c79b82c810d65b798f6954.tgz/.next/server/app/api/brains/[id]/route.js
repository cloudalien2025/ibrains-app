var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/brains/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0ee2cbe2._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_brains_[id]_route_actions_f333e81f.js")
R.m(43449)
module.exports=R.m(43449).exports
