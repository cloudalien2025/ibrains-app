var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/mission-control/[check]/route.js")
R.c("server/chunks/[root-of-the-server]__0032d035._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_mission-control_[check]_route_actions_9904d7b2.js")
R.m(36376)
module.exports=R.m(36376).exports
