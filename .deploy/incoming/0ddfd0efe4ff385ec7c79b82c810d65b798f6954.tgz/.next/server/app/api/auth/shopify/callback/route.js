var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/shopify/callback/route.js")
R.c("server/chunks/[root-of-the-server]__49683196._.js")
R.c("server/chunks/[root-of-the-server]__ab6f7df1._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/_716d2194._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_shopify_callback_route_actions_846ebc61.js")
R.m(38078)
module.exports=R.m(38078).exports
