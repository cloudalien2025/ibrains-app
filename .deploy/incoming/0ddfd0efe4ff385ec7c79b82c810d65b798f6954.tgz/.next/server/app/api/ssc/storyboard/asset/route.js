var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/ssc/storyboard/asset/route.js")
R.c("server/chunks/[root-of-the-server]__f1cbf6f1._.js")
R.c("server/chunks/[root-of-the-server]__9d217c47._.js")
R.c("server/chunks/_next-internal_server_app_api_ssc_storyboard_asset_route_actions_fb00823c.js")
R.m(86948)
module.exports=R.m(86948).exports
