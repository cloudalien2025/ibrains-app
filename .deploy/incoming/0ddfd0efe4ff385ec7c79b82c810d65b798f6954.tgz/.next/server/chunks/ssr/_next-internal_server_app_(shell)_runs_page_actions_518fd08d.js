module.exports=[24123,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28shell%29_runs_page_actions_518fd08d.js.map