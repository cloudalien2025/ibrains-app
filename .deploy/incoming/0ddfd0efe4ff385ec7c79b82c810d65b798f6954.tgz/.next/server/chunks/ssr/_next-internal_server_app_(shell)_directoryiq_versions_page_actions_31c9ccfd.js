module.exports=[43864,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28shell%29_directoryiq_versions_page_actions_31c9ccfd.js.map