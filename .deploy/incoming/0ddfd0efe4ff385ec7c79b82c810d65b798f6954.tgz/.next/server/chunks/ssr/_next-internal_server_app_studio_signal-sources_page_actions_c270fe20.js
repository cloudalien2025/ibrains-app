module.exports=[44783,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_studio_signal-sources_page_actions_c270fe20.js.map