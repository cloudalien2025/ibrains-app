module.exports=[53512,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28shell%29_mission-control_page_actions_3ce58d57.js.map