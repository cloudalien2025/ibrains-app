module.exports=[60411,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28shell%29_directoryiq_settings_page_actions_5bc6e89c.js.map