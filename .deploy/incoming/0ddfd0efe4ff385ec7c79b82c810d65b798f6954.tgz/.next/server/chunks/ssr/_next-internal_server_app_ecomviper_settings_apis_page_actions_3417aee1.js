module.exports=[94622,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ecomviper_settings_apis_page_actions_3417aee1.js.map