module.exports=[54111,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ecomviper_page_actions_fed98efe.js.map