module.exports=[65556,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ecomviper_settings_integrations_page_actions_6ed51e4a.js.map