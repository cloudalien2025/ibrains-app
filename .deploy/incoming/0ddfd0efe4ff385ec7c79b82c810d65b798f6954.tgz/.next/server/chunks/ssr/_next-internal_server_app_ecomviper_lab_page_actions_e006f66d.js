module.exports=[76886,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ecomviper_lab_page_actions_e006f66d.js.map