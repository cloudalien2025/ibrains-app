module.exports=[17064,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28shell%29_brains_%5Bid%5D_page_actions_a9859997.js.map