module.exports=[87477,(a,b,c)=>{}];

//# sourceMappingURL=bec2d_app_%28shell%29_directoryiq_authority_authority-support_page_actions_e5e00db8.js.map