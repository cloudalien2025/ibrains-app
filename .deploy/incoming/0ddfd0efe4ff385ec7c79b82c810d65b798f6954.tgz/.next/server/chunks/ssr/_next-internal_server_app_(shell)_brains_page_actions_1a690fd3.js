module.exports=[93612,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28shell%29_brains_page_actions_1a690fd3.js.map