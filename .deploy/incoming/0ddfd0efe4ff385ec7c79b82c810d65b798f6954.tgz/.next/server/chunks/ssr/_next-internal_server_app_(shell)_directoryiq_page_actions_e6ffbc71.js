module.exports=[89065,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28shell%29_directoryiq_page_actions_e6ffbc71.js.map