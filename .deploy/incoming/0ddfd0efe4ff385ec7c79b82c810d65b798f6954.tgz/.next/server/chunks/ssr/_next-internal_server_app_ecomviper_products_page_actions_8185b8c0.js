module.exports=[54106,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ecomviper_products_page_actions_8185b8c0.js.map