module.exports=[18906,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28shell%29_directoryiq_authority_page_actions_4e548eb4.js.map