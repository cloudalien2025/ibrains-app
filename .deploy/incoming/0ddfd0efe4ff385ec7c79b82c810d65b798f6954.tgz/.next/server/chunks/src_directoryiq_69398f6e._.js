module.exports=[78247,e=>e.a(async(t,n)=>{try{var i=e.i(95380),o=t([i]);async function a(e){return(await (0,i.queryDb)(`
    INSERT INTO authority_graph_nodes (tenant_id, node_type, external_id, canonical_url, title, meta)
    VALUES ($1, $2, $3, $4, $5, $6::jsonb)
    ON CONFLICT (tenant_id, node_type, external_id)
    DO UPDATE SET
      canonical_url = EXCLUDED.canonical_url,
      title = EXCLUDED.title,
      meta = EXCLUDED.meta,
      status = 'active',
      updated_at = now()
    RETURNING id, tenant_id, node_type, external_id, canonical_url, title
    `,[e.tenantId,e.nodeType,e.externalId,e.canonicalUrl??null,e.title??null,JSON.stringify(e.meta??{})]))[0]}async function l(e){return(await (0,i.queryDb)(`
    INSERT INTO authority_graph_edges
      (tenant_id, from_node_id, to_node_id, edge_type, strength, confidence, status, first_seen_at, last_seen_at)
    VALUES
      ($1, $2, $3, $4, $5, $6, $7, $8::timestamptz, $9::timestamptz)
    ON CONFLICT (tenant_id, from_node_id, to_node_id, edge_type)
    DO UPDATE SET
      strength = EXCLUDED.strength,
      confidence = EXCLUDED.confidence,
      status = EXCLUDED.status,
      first_seen_at = LEAST(authority_graph_edges.first_seen_at, EXCLUDED.first_seen_at),
      last_seen_at = GREATEST(authority_graph_edges.last_seen_at, EXCLUDED.last_seen_at),
      updated_at = now()
    RETURNING id
    `,[e.tenantId,e.fromNodeId,e.toNodeId,e.edgeType,e.strength??50,e.confidence??80,e.status??"active",e.firstSeenAt??new Date().toISOString(),e.lastSeenAt??new Date().toISOString()]))[0]}async function r(e){await (0,i.queryDb)(`
    INSERT INTO authority_graph_evidence
      (tenant_id, edge_id, source_url, target_url, anchor_text, context_snippet, dom_path, location_hint, detected_at)
    VALUES
      ($1, $2, $3, $4, $5, $6, $7, $8, $9::timestamptz)
    `,[e.tenantId,e.edgeId,e.sourceUrl,e.targetUrl??null,e.anchorText??null,e.contextSnippet??null,e.domPath??null,e.locationHint??"unknown",e.detectedAt??new Date().toISOString()])}async function d(e){return(await (0,i.queryDb)(`
    INSERT INTO authority_graph_runs (tenant_id, run_type, status)
    VALUES ($1, $2, 'started')
    RETURNING id, started_at
    `,[e.tenantId,e.runType]))[0]}async function s(e){await (0,i.queryDb)(`
    UPDATE authority_graph_runs
    SET
      status = $2,
      stats = $3::jsonb,
      error = $4,
      completed_at = now()
    WHERE id = $1
    `,[e.runId,e.status,JSON.stringify(e.stats),e.error??null])}async function _(e){return(0,i.queryDb)(`
    SELECT
      l.id AS to_node_id,
      l.external_id AS to_external_id,
      l.title AS to_title,
      l.canonical_url AS to_canonical_url
    FROM authority_graph_nodes l
    LEFT JOIN authority_graph_edges e
      ON e.tenant_id = l.tenant_id
     AND e.to_node_id = l.id
     AND e.edge_type = 'internal_link'
     AND e.status = 'active'
    LEFT JOIN authority_graph_nodes b
      ON b.id = e.from_node_id
     AND b.node_type = 'blog_post'
    WHERE l.tenant_id = $1
      AND l.node_type = 'listing'
      AND l.status = 'active'
    GROUP BY l.id, l.external_id, l.title, l.canonical_url
    HAVING COUNT(b.id) = 0
    ORDER BY l.title NULLS LAST, l.external_id
    `,[e])}async function c(e){return(0,i.queryDb)(`
    SELECT
      e.id AS edge_id,
      b.id AS from_node_id,
      b.external_id AS from_external_id,
      b.title AS from_title,
      b.canonical_url AS from_canonical_url,
      l.id AS to_node_id,
      l.external_id AS to_external_id,
      l.title AS to_title,
      l.canonical_url AS to_canonical_url,
      ev.source_url AS evidence_source_url,
      ev.target_url AS evidence_target_url,
      ev.anchor_text AS evidence_anchor_text,
      ev.context_snippet AS evidence_context_snippet,
      ev.dom_path AS evidence_dom_path,
      ev.location_hint AS evidence_location_hint
    FROM authority_graph_edges e
    INNER JOIN authority_graph_nodes b
      ON b.id = e.from_node_id
    INNER JOIN authority_graph_nodes l
      ON l.id = e.to_node_id
    LEFT JOIN LATERAL (
      SELECT source_url, target_url, anchor_text, context_snippet, dom_path, location_hint
      FROM authority_graph_evidence ev
      WHERE ev.edge_id = e.id
      ORDER BY detected_at DESC
      LIMIT 1
    ) ev ON true
    WHERE e.tenant_id = $1
      AND e.edge_type = 'mention_without_link'
      AND e.status = 'active'
    ORDER BY e.last_seen_at DESC
    `,[e])}async function u(e){return(0,i.queryDb)(`
    SELECT
      e.id AS edge_id,
      b.id AS from_node_id,
      b.external_id AS from_external_id,
      b.title AS from_title,
      b.canonical_url AS from_canonical_url,
      l.id AS to_node_id,
      l.external_id AS to_external_id,
      l.title AS to_title,
      l.canonical_url AS to_canonical_url,
      ev.source_url AS evidence_source_url,
      ev.target_url AS evidence_target_url,
      ev.anchor_text AS evidence_anchor_text,
      ev.context_snippet AS evidence_context_snippet,
      ev.dom_path AS evidence_dom_path,
      ev.location_hint AS evidence_location_hint
    FROM authority_graph_edges e
    INNER JOIN authority_graph_nodes b
      ON b.id = e.from_node_id
    INNER JOIN authority_graph_nodes l
      ON l.id = e.to_node_id
    LEFT JOIN LATERAL (
      SELECT source_url, target_url, anchor_text, context_snippet, dom_path, location_hint
      FROM authority_graph_evidence ev
      WHERE ev.edge_id = e.id
      ORDER BY detected_at DESC
      LIMIT 1
    ) ev ON true
    WHERE e.tenant_id = $1
      AND e.edge_type = 'weak_anchor'
      AND e.status = 'active'
    ORDER BY e.last_seen_at DESC
    `,[e])}async function g(e){let t=(await (0,i.queryDb)(`
    SELECT id, status, stats, started_at, completed_at
    FROM authority_graph_runs
    WHERE tenant_id = $1
    ORDER BY started_at DESC
    LIMIT 1
    `,[e]))[0];return t?{id:t.id,status:t.status,stats:t.stats??{},startedAt:t.started_at,completedAt:t.completed_at}:null}async function p(e){return(await (0,i.queryDb)(`
    SELECT
      (
        SELECT COUNT(*)::int
        FROM authority_graph_nodes n
        WHERE n.tenant_id = $1
          AND n.status = 'active'
      ) AS total_nodes,
      (
        SELECT COUNT(*)::int
        FROM authority_graph_edges e
        WHERE e.tenant_id = $1
          AND e.status = 'active'
      ) AS total_edges,
      (
        SELECT COUNT(*)::int
        FROM authority_graph_evidence ev
        WHERE ev.tenant_id = $1
      ) AS total_evidence,
      (
        SELECT COUNT(*)::int
        FROM authority_graph_nodes n
        WHERE n.tenant_id = $1
          AND n.status = 'active'
          AND n.node_type = 'blog_post'
      ) AS blog_nodes,
      (
        SELECT COUNT(*)::int
        FROM authority_graph_nodes n
        WHERE n.tenant_id = $1
          AND n.status = 'active'
          AND n.node_type = 'listing'
      ) AS listing_nodes
    `,[e]))[0]??{total_nodes:0,total_edges:0,total_evidence:0,blog_nodes:0,listing_nodes:0}}async function h(e){return(0,i.queryDb)(`
    SELECT
      b.id AS blog_node_id,
      b.external_id AS blog_external_id,
      b.title AS blog_title,
      b.canonical_url AS blog_url,
      e.edge_type AS edge_type,
      l.id AS listing_node_id,
      l.external_id AS listing_external_id,
      l.title AS listing_title,
      l.canonical_url AS listing_url,
      ev.context_snippet AS evidence_snippet,
      ev.anchor_text AS evidence_anchor_text
    FROM authority_graph_nodes b
    LEFT JOIN authority_graph_edges e
      ON e.tenant_id = b.tenant_id
     AND e.from_node_id = b.id
     AND e.status = 'active'
     AND e.edge_type IN ('internal_link', 'mention_without_link')
    LEFT JOIN authority_graph_nodes l
      ON l.id = e.to_node_id
     AND l.node_type = 'listing'
    LEFT JOIN LATERAL (
      SELECT context_snippet, anchor_text
      FROM authority_graph_evidence ev
      WHERE ev.edge_id = e.id
      ORDER BY ev.detected_at DESC
      LIMIT 1
    ) ev ON true
    WHERE b.tenant_id = $1
      AND b.node_type = 'blog_post'
      AND b.status = 'active'
      AND (b.meta->>'mock') IS DISTINCT FROM 'true'
    ORDER BY b.updated_at DESC, b.title NULLS LAST
    `,[e])}async function m(e){return(0,i.queryDb)(`
    SELECT
      l.id AS listing_node_id,
      l.external_id AS listing_external_id,
      l.title AS listing_title,
      l.canonical_url AS listing_url,
      e.edge_type AS edge_type,
      b.id AS blog_node_id,
      b.external_id AS blog_external_id,
      b.title AS blog_title,
      b.canonical_url AS blog_url,
      ev.context_snippet AS evidence_snippet,
      ev.anchor_text AS evidence_anchor_text
    FROM authority_graph_nodes l
    LEFT JOIN authority_graph_edges e
      ON e.tenant_id = l.tenant_id
     AND e.to_node_id = l.id
     AND e.status = 'active'
     AND e.edge_type IN ('internal_link', 'mention_without_link')
    LEFT JOIN authority_graph_nodes b
      ON b.id = e.from_node_id
     AND b.node_type = 'blog_post'
    LEFT JOIN LATERAL (
      SELECT context_snippet, anchor_text
      FROM authority_graph_evidence ev
      WHERE ev.edge_id = e.id
      ORDER BY ev.detected_at DESC
      LIMIT 1
    ) ev ON true
    WHERE l.tenant_id = $1
      AND l.node_type = 'listing'
      AND l.status = 'active'
      AND (l.meta->>'mock') IS DISTINCT FROM 'true'
    ORDER BY l.updated_at DESC, l.title NULLS LAST
    `,[e])}[i]=o.then?(await o)():o,e.s(["addEvidence",()=>r,"createRun",()=>d,"finishRun",()=>s,"getGraphSummaryCounts",()=>p,"getLatestRun",()=>g,"listBlogLayerRows",()=>h,"listListingLayerRows",()=>m,"listMentionsWithoutLinks",()=>c,"listOrphanListings",()=>_,"listWeakAnchors",()=>u,"upsertEdge",()=>l,"upsertNode",()=>a]),n()}catch(e){n(e)}},!1),68825,e=>{"use strict";let t=new Set(["click here","here","learn more","read more","view more","more","this link","link","website","visit"]);function n(e){let n=e.trim().toLowerCase().replace(/\s+/g," ");return!n||n.length<=2||t.has(n)}e.s(["weakAnchorDetector",()=>n])},69014,e=>e.a(async(t,n)=>{try{var i=e.i(95380),o=e.i(78247),a=e.i(68825),l=t([i,o]);[i,o]=l.then?(await l)():l;let w="https://example.com/blog/authority-tips",v="https://example.com/listings/acme-plumbing",T={orphans:[{type:"orphan_listing",severity:"high",to:{nodeType:"listing",externalId:"listing-001",title:"Acme Plumbing",canonicalUrl:v},evidence:null,details:{summary:"Listing has no internal blog links pointing to it.",suggestedFix:"Add at least one contextual internal link from a relevant blog post to the listing page."}}],mentions_without_links:[{type:"mention_without_link",severity:"medium",from:{nodeType:"blog_post",externalId:"blog-001",title:"How to Pick a Reliable Plumber",canonicalUrl:w},to:{nodeType:"listing",externalId:"listing-001",title:"Acme Plumbing",canonicalUrl:v},evidence:{sourceUrl:w,targetUrl:v,anchorText:null,contextSnippet:"Acme Plumbing serves the local area with emergency response.",locationHint:"body"},details:{summary:"Blog post mentions the listing by name but does not link to the listing URL.",suggestedFix:"Add a contextual internal link on the mention to strengthen authority flow."}}],weak_anchors:[{type:"weak_anchor",severity:"low",from:{nodeType:"blog_post",externalId:"blog-001",title:"How to Pick a Reliable Plumber",canonicalUrl:w},to:{nodeType:"listing",externalId:"listing-001",title:"Acme Plumbing",canonicalUrl:v},evidence:{sourceUrl:w,targetUrl:v,anchorText:"click here",contextSnippet:"For details, click here.",locationHint:"body"},details:{summary:"Internal listing link uses a weak anchor text.",suggestedFix:"Replace generic anchor text with a descriptive phrase that names the listing or service intent."}}],lastRun:null};function r(e){return e?e.trim().toLowerCase().replace(/\/$/,""):""}function d(e){return"string"==typeof e?e:""}function s(e){return e.replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim()}function _(e){let t=e.trim();if(!t)return"";try{return new URL(t,"https://directoryiq.local").pathname.toLowerCase().replace(/\/+$/,"")}catch{return t.split("?")[0].split("#")[0].toLowerCase().replace(/\/+$/,"")}}function c(e){return e.toLowerCase().replace(/&[a-z0-9#]+;/gi," ").replace(/[^a-z0-9]+/g," ").replace(/\s+/g," ").trim()}function u(e,t){let n=e.toLowerCase(),i=t.toLowerCase(),o=n.indexOf(i);if(o<0)return e.slice(0,180);let a=Math.max(0,o-80),l=Math.min(e.length,o+i.length+80);return e.slice(a,l).trim()}function g(e){let t=e.evidence_source_url;return t?{sourceUrl:t,targetUrl:e.evidence_target_url??null,anchorText:e.evidence_anchor_text??null,contextSnippet:e.evidence_context_snippet??null,domPath:e.evidence_dom_path??null,locationHint:e.evidence_location_hint??"unknown"}:null}function p(e){return{type:"mention_without_link",severity:"medium",from:{nodeId:e.from_node_id,nodeType:"blog_post",externalId:e.from_external_id,title:e.from_title??null,canonicalUrl:e.from_canonical_url??null},to:{nodeId:e.to_node_id,nodeType:"listing",externalId:e.to_external_id,title:e.to_title??null,canonicalUrl:e.to_canonical_url??null},evidence:g(e),details:{summary:"Blog mentions listing without an internal link.",suggestedFix:"Convert the mention into a contextual internal link to the listing URL."}}}function h(e){return{type:"weak_anchor",severity:"low",from:{nodeId:e.from_node_id,nodeType:"blog_post",externalId:e.from_external_id,title:e.from_title??null,canonicalUrl:e.from_canonical_url??null},to:{nodeId:e.to_node_id,nodeType:"listing",externalId:e.to_external_id,title:e.to_title??null,canonicalUrl:e.to_canonical_url??null},evidence:g(e),details:{summary:"Internal link uses weak anchor text.",suggestedFix:"Replace generic anchor text with descriptive anchor language tied to listing intent."}}}function m(e){return{type:"orphan_listing",severity:"high",to:{nodeId:e.to_node_id,nodeType:"listing",externalId:e.to_external_id,title:e.to_title??null,canonicalUrl:e.to_canonical_url??null},evidence:null,details:{summary:"No blog post currently links to this listing.",suggestedFix:"Add at least one relevant blog post link pointing to this listing page."}}}async function y(){return(0,i.queryDb)(`
    SELECT source_id, title, url, raw_json
    FROM directoryiq_nodes
    WHERE source_type = 'listing'
    ORDER BY updated_at DESC
    `)}async function E(){return(0,i.queryDb)(`
    SELECT source_id, title, url, raw_json
    FROM directoryiq_nodes
    WHERE source_type = 'blog_post'
    ORDER BY updated_at DESC
    `)}async function I(e){let t=await (0,o.createRun)({tenantId:e,runType:"scan"}),n=await (0,o.upsertNode)({tenantId:e,nodeType:"listing",externalId:"listing-001",canonicalUrl:v,title:"Acme Plumbing",meta:{mock:!0}}),i=await (0,o.upsertNode)({tenantId:e,nodeType:"blog_post",externalId:"blog-001",canonicalUrl:w,title:"How to Pick a Reliable Plumber",meta:{mock:!0}}),a=await (0,o.upsertEdge)({tenantId:e,fromNodeId:i.id,toNodeId:n.id,edgeType:"mention_without_link",strength:45,confidence:90});await (0,o.addEvidence)({tenantId:e,edgeId:a.id,sourceUrl:w,targetUrl:v,contextSnippet:"Acme Plumbing serves the local area with emergency response.",locationHint:"body"});let l=await (0,o.upsertEdge)({tenantId:e,fromNodeId:i.id,toNodeId:n.id,edgeType:"weak_anchor",strength:40,confidence:88});return await (0,o.addEvidence)({tenantId:e,edgeId:l.id,sourceUrl:w,targetUrl:v,anchorText:"click here",contextSnippet:"For details, click here.",locationHint:"body"}),await (0,o.finishRun)({runId:t.id,status:"completed",stats:{nodesCreated:2,edgesUpserted:2,evidenceCount:2,issuesCounts:{orphans:1,mentions_without_links:1,weak_anchors:1}}}),{runId:t.id}}async function f(e){if("1"===process.env.E2E_MOCK_GRAPH)return process.env.DATABASE_URL?{runId:(await I(e.tenantId)).runId,stats:{nodesCreated:2,edgesUpserted:2,evidenceCount:2,issuesCounts:{orphans:1,mentions_without_links:1,weak_anchors:1}}}:{runId:"mock-run-001",stats:{nodesCreated:2,edgesUpserted:2,evidenceCount:2,issuesCounts:{orphans:1,mentions_without_links:1,weak_anchors:1}}};let t=await (0,o.createRun)({tenantId:e.tenantId,runType:"scan"});try{let n=await y(),i=await E(),l=Number.parseInt(process.env.DIRECTORYIQ_AUTHORITY_MAX_BLOGS??"500",10)||500,g=i.slice(0,l),p=new Map,h=new Map,m=new Map,I=0,f=0,b=0;for(let t of n){let n=await (0,o.upsertNode)({tenantId:e.tenantId,nodeType:"listing",externalId:t.source_id,canonicalUrl:t.url,title:t.title,meta:{source:"directoryiq_nodes",sourceType:"listing"}});I+=1;let i=r(t.url),a=(t.title??t.source_id).trim();p.set(t.source_id,{id:n.id,url:i,title:a}),i&&h.set(i,{id:n.id,sourceId:t.source_id,title:a,url:t.url??""});let l=t.raw_json??{},s=_(d(l.listing_slug??l.group_filename??l.slug??l.path??""));s&&m.set(s,{id:n.id,sourceId:t.source_id,title:a,url:t.url??s})}let A=!1,S=0,x=0,w=0,v=0,T=0,N=n.find(e=>(e.title??"").toLowerCase().includes("arrabelle"));for(let t of g){let i=t.raw_json??{},l=await (0,o.upsertNode)({tenantId:e.tenantId,nodeType:"blog_post",externalId:t.source_id,canonicalUrl:t.url,title:t.title,meta:{source:"directoryiq_nodes",sourceType:"blog_post"}});I+=1;let g=function(e){let t=e.content;if("string"==typeof t&&t.trim())return t;if(t&&"object"==typeof t){let e=d(t.rendered);if(e.trim())return e}for(let t of[e.body_html,e.html,e.post_content,e.description,e.excerpt]){let e=d(t);if(e.trim())return e}return""}(i),y=function(e){for(let t of[e.clean_text,e.body,e.post_content,e.raw_html,e.body_html,e.content_html,e.excerpt,e.description,e.summary,e.title,e.post_title,e.content])if("string"==typeof t&&t.trim())return s(t);let t=e.content;if(t&&"object"==typeof t){let e=d(t.rendered);if(e.trim())return s(e)}return""}(i);(g||y)&&(A=!0),g.trim()&&(S+=1),x+=y.length;let E=function(e){let t=[],n=/<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi,i=n.exec(e);for(;i;){let o=(i[1]??"").trim(),a=s(i[2]??"");o&&t.push({href:o,text:a}),i=n.exec(e)}return t}(g);w+=E.length;let R=new Set,L=0,D=0;for(let n of E){let i=r(n.href),d=_(n.href);if(d){let i=m.get(d);if(i){R.add(i.id);let r=await (0,o.upsertEdge)({tenantId:e.tenantId,fromNodeId:l.id,toNodeId:i.id,edgeType:"internal_link",strength:90,confidence:95});if(f+=1,v+=1,L+=1,await (0,o.addEvidence)({tenantId:e.tenantId,edgeId:r.id,sourceUrl:t.url??`blog:${t.source_id}`,targetUrl:i.url,anchorText:n.text,contextSnippet:u(s(g||y),n.text||i.title),domPath:"a",locationHint:"body"}),b+=1,(0,a.weakAnchorDetector)(n.text)){let a=await (0,o.upsertEdge)({tenantId:e.tenantId,fromNodeId:l.id,toNodeId:i.id,edgeType:"weak_anchor",strength:40,confidence:85});f+=1,await (0,o.addEvidence)({tenantId:e.tenantId,edgeId:a.id,sourceUrl:t.url??`blog:${t.source_id}`,targetUrl:i.url,anchorText:n.text,contextSnippet:u(s(g||y),n.text||i.title),domPath:"a",locationHint:"body"}),b+=1}continue}}if(i)for(let r of h.values()){if(!r.url||!i.includes(r.url))continue;R.add(r.id);let d=await (0,o.upsertEdge)({tenantId:e.tenantId,fromNodeId:l.id,toNodeId:r.id,edgeType:"internal_link",strength:90,confidence:95});if(f+=1,v+=1,L+=1,await (0,o.addEvidence)({tenantId:e.tenantId,edgeId:d.id,sourceUrl:t.url??`blog:${t.source_id}`,targetUrl:r.url,anchorText:n.text,contextSnippet:u(s(g||y),n.text||r.title),domPath:"a",locationHint:"body"}),b+=1,(0,a.weakAnchorDetector)(n.text)){let i=await (0,o.upsertEdge)({tenantId:e.tenantId,fromNodeId:l.id,toNodeId:r.id,edgeType:"weak_anchor",strength:40,confidence:85});f+=1,await (0,o.addEvidence)({tenantId:e.tenantId,edgeId:i.id,sourceUrl:t.url??`blog:${t.source_id}`,targetUrl:r.url,anchorText:n.text,contextSnippet:u(s(g||y),n.text||r.title),domPath:"a",locationHint:"body"}),b+=1}}}let O=c(y||s(g)),k=` ${O} `;for(let i of n){let n=p.get(i.source_id);if(!n||R.has(n.id))continue;let a=(i.title??"").trim();if(a.length<3)continue;let r=(function(e){let t=c(e);if(!t)return[];let n=new Set([t]);return t.startsWith("the ")&&n.add(t.slice(4).trim()),n.add(t.replace(/\bat\b/g," ").replace(/\s+/g," ").trim()),n.add(t.replace(/\b(hotel|inn|resort)\b/g," ").replace(/\s+/g," ").trim()),Array.from(n).filter(e=>e.length>=3)})(a).find(e=>k.includes(` ${e} `));if(!r)continue;let d=await (0,o.upsertEdge)({tenantId:e.tenantId,fromNodeId:l.id,toNodeId:n.id,edgeType:"mention_without_link",strength:45,confidence:75});f+=1,T+=1,D+=1,await (0,o.addEvidence)({tenantId:e.tenantId,edgeId:d.id,sourceUrl:t.url??`blog:${t.source_id}`,targetUrl:i.url,contextSnippet:u(y||s(g),r),locationHint:"body"}),b+=1}let C="51"===t.source_id&&!!N&&O.includes((N.title??"").trim().toLowerCase());"51"===t.source_id&&console.info(`[directoryiq-authority-graph] EXPECT_MATCH listing="${N?.title??"none"}" blog="${t.title??t.source_id}" => ${C}`),console.info(`[directoryiq-authority-graph] blog=${t.source_id} links=${L} mentions=${D}`)}let R=await (0,o.listOrphanListings)(e.tenantId),L=await (0,o.listMentionsWithoutLinks)(e.tenantId),D=await (0,o.listWeakAnchors)(e.tenantId),O={nodesCreated:I,edgesUpserted:f,evidenceCount:b,issuesCounts:{orphans:R.length,mentions_without_links:L.length,weak_anchors:D.length}};return A||(O.limitedScanner={enabled:!0,reason:"Blog body content is unavailable; scanner used title/excerpt-level signals only."}),console.info(`[directoryiq-authority-graph] Ingestion Debug Summary blogs_fetched=${g.length} blogs_with_raw_html=${S} avg_clean_text_length=${g.length?Math.round(x/g.length):0} hrefs_extracted_total=${w} links_to_edges_upserted=${v} mentions_edges_upserted=${T}`),await (0,o.finishRun)({runId:t.id,status:"completed",stats:O}),{runId:t.id,stats:O}}catch(n){let e=n instanceof Error?n.message:"Unknown graph scan error";throw await (0,o.finishRun)({runId:t.id,status:"failed",stats:{nodesCreated:0,edgesUpserted:0,evidenceCount:0,issuesCounts:{orphans:0,mentions_without_links:0,weak_anchors:0}},error:e}),n}}async function b(e){if("1"===process.env.E2E_MOCK_GRAPH)return{...T,lastRun:{id:"mock-run-001",status:"completed",startedAt:"2026-03-03T00:00:00.000Z",completedAt:"2026-03-03T00:00:01.000Z",stats:{nodesCreated:2,edgesUpserted:2,evidenceCount:2,issuesCounts:{orphans:1,mentions_without_links:1,weak_anchors:1}}}};let[t,n,i,a]=await Promise.all([(0,o.listOrphanListings)(e.tenantId),(0,o.listMentionsWithoutLinks)(e.tenantId),(0,o.listWeakAnchors)(e.tenantId),(0,o.getLatestRun)(e.tenantId)]);return{orphans:t.map(m),mentions_without_links:n.map(p),weak_anchors:i.map(h),lastRun:a?{id:a.id,status:a.status,startedAt:a.startedAt,completedAt:a.completedAt,stats:a.stats}:null}}async function A(e){let[t,n,a]=await Promise.all([(0,o.getGraphSummaryCounts)(e.tenantId),(0,o.getLatestRun)(e.tenantId),(0,i.queryDb)(`
      SELECT finished_at
      FROM directoryiq_ingest_runs
      WHERE user_id = $1
        AND status = 'succeeded'
      ORDER BY finished_at DESC NULLS LAST
      LIMIT 1
      `,[e.userId])]);return{totalNodes:t.total_nodes,totalEdges:t.total_edges,totalEvidence:t.total_evidence,blogNodes:t.blog_nodes,listingNodes:t.listing_nodes,lastIngestionRunAt:a[0]?.finished_at??null,lastGraphRunAt:n?.completedAt??n?.startedAt??null,lastGraphRunStatus:n?.status??null}}async function S(e){let t=await (0,o.listBlogLayerRows)(e.tenantId),n=new Map;for(let e of t){let t=n.get(e.blog_node_id);t?t.rows.push(e):n.set(e.blog_node_id,{head:e,rows:[e]})}return Array.from(n.values()).map(({head:e,rows:t})=>{let n=t.filter(e=>"internal_link"===e.edge_type&&e.listing_node_id),i=t.filter(e=>"mention_without_link"===e.edge_type&&e.listing_node_id),o=t.filter(e=>e.listing_node_id&&("internal_link"===e.edge_type||"mention_without_link"===e.edge_type)),a=new Set(n.map(e=>e.listing_node_id)),l=new Set(i.map(e=>e.listing_node_id)),r=o.map(e=>({entityText:e.listing_title??e.listing_external_id??"Listing",entityType:"listing",evidenceSnippet:e.evidence_snippet??null})),d=i.map(e=>({listingExternalId:e.listing_external_id??"",listingTitle:e.listing_title??e.listing_external_id??"Listing",listingUrl:e.listing_url??null,recommendation:`Add link to ${e.listing_title??e.listing_external_id??"listing"} using anchor "${e.listing_title??"Listing details"}".`})),s=d.map(e=>e.recommendation),_=a.size,c=l.size;return{blogNodeId:e.blog_node_id,blogExternalId:e.blog_external_id,blogTitle:e.blog_title,blogUrl:e.blog_url,extractedEntitiesCount:new Set(r.map(e=>e.entityText)).size,linkedListingsCount:_,unlinkedMentionsCount:c,status:_>0?"green":c>0?"yellow":"red",entities:r,suggestedListingTargets:d,missingInternalLinksRecommendations:s}})}async function x(e){let t=await (0,o.listListingLayerRows)(e.tenantId),n=new Map;for(let e of t){let t=n.get(e.listing_node_id);t?t.rows.push(e):n.set(e.listing_node_id,{head:e,rows:[e]})}return Array.from(n.values()).map(({head:e,rows:t})=>{let n=t.filter(e=>"internal_link"===e.edge_type&&e.blog_node_id),i=t.filter(e=>"mention_without_link"===e.edge_type&&e.blog_node_id),o=new Set(n.map(e=>e.blog_node_id)),a=new Set(i.map(e=>e.blog_node_id)),l=t.filter(e=>e.blog_node_id&&("internal_link"===e.edge_type||"mention_without_link"===e.edge_type)).map(e=>({blogExternalId:e.blog_external_id??"",blogTitle:e.blog_title,blogUrl:e.blog_url,edgeType:"internal_link"===e.edge_type?"links_to":"mentions",evidenceSnippet:e.evidence_snippet,anchorText:e.evidence_anchor_text})),r=i.map(e=>({blogExternalId:e.blog_external_id??"",blogTitle:e.blog_title,blogUrl:e.blog_url,edgeType:"mentions",evidenceSnippet:e.evidence_snippet,anchorText:e.evidence_anchor_text})),d=o.size,s=a.size;return{listingNodeId:e.listing_node_id,listingExternalId:e.listing_external_id,listingTitle:e.listing_title,listingUrl:e.listing_url,inboundBlogLinksCount:d,mentionedInCount:s,status:d>0?"green":s>0?"yellow":"red",inboundBlogs:l,suggestedBlogsToLinkFrom:r}})}e.s(["getAuthorityBlogs",()=>S,"getAuthorityListings",()=>x,"getAuthorityOverview",()=>A,"getIssues",()=>b,"rebuildGraph",()=>f]),n()}catch(e){n(e)}},!1)];

//# sourceMappingURL=src_directoryiq_69398f6e._.js.map