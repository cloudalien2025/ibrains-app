module.exports=[23398,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ecomviper_snapshot_route_actions_ca454703.js.map