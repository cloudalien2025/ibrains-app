module.exports=[70406,(e,t,T)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,T)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},54799,(e,t,T)=>{t.exports=e.x("crypto",()=>require("crypto"))},23862,e=>e.a(async(t,T)=>{try{let t=await e.y("pg-587764f78a6c7a9c");e.n(t),T()}catch(e){T(e)}},!0),18669,e=>e.a(async(t,T)=>{try{var r=e.i(23862),E=t([r]);[r]=E.then?(await E)():E;let n=null,o=!1,N=null;function i(){if(!n){let e=process.env.DATABASE_URL;if(!e)throw Error("DATABASE_URL not configured");n=new r.Pool({connectionString:e})}return n}async function s(){o||(N||(N=(async()=>{let e=i();await e.query(`
        CREATE EXTENSION IF NOT EXISTS pgcrypto;

        CREATE TABLE IF NOT EXISTS users (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          external_id TEXT UNIQUE,
          email TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE TABLE IF NOT EXISTS integrations (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          provider TEXT NOT NULL,
          shop_domain TEXT NOT NULL,
          access_token_ciphertext TEXT NOT NULL,
          scopes TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'connected',
          installed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          last_verified_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, provider, shop_domain)
        );

        CREATE TABLE IF NOT EXISTS oauth_states (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          provider TEXT NOT NULL,
          shop_domain TEXT NOT NULL,
          state TEXT NOT NULL UNIQUE,
          expires_at TIMESTAMPTZ NOT NULL,
          used_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE TABLE IF NOT EXISTS ingest_runs (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
          status TEXT NOT NULL,
          started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          finished_at TIMESTAMPTZ,
          products_count INTEGER NOT NULL DEFAULT 0,
          articles_count INTEGER NOT NULL DEFAULT 0,
          pages_count INTEGER NOT NULL DEFAULT 0,
          collections_count INTEGER NOT NULL DEFAULT 0,
          error_message TEXT
        );

        CREATE TABLE IF NOT EXISTS site_nodes (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
          node_type TEXT NOT NULL,
          source_id TEXT NOT NULL,
          handle TEXT,
          title TEXT NOT NULL,
          url TEXT,
          tags JSONB NOT NULL DEFAULT '[]',
          body_text TEXT,
          body_html TEXT,
          image_url TEXT,
          published_at TIMESTAMPTZ,
          updated_at_source TIMESTAMPTZ,
          raw_json JSONB NOT NULL DEFAULT '{}',
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (integration_id, source_id)
        );

        CREATE INDEX IF NOT EXISTS idx_site_nodes_integration_type
          ON site_nodes(integration_id, node_type);

        CREATE TABLE IF NOT EXISTS product_blog_links (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
          product_node_id UUID NOT NULL REFERENCES site_nodes(id) ON DELETE CASCADE,
          article_node_id UUID NOT NULL REFERENCES site_nodes(id) ON DELETE CASCADE,
          score NUMERIC NOT NULL,
          reason TEXT NOT NULL,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (product_node_id, article_node_id)
        );

        CREATE TABLE IF NOT EXISTS byo_api_keys (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          provider TEXT NOT NULL,
          key_ciphertext TEXT NOT NULL,
          key_last4 TEXT,
          key_length INTEGER,
          label TEXT,
          last_verified_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, provider)
        );

        ALTER TABLE byo_api_keys
          ADD COLUMN IF NOT EXISTS key_last4 TEXT;

        ALTER TABLE byo_api_keys
          ADD COLUMN IF NOT EXISTS key_length INTEGER;

        ALTER TABLE byo_api_keys
          ADD COLUMN IF NOT EXISTS last_verified_at TIMESTAMPTZ;

        CREATE TABLE IF NOT EXISTS directoryiq_signal_source_credentials (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          connector_id TEXT NOT NULL,
          secret_ciphertext TEXT NOT NULL,
          secret_last4 TEXT,
          secret_length INTEGER,
          label TEXT,
          config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          last_verified_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, connector_id)
        );

        CREATE TABLE IF NOT EXISTS integrations_credentials (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          product TEXT NOT NULL,
          provider TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'connected',
          secret_ciphertext TEXT,
          secret_iv TEXT,
          secret_tag TEXT,
          secret_last4 TEXT,
          meta_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          saved_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, product, provider)
        );

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'connected';

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_ciphertext TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_iv TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_tag TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_last4 TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS meta_json JSONB NOT NULL DEFAULT '{}'::jsonb;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS saved_at TIMESTAMPTZ NOT NULL DEFAULT now();

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS secret_last4 TEXT;

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS secret_length INTEGER;

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS last_verified_at TIMESTAMPTZ;

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS config_json JSONB NOT NULL DEFAULT '{}'::jsonb;

        CREATE TABLE IF NOT EXISTS directoryiq_ingest_runs (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          status TEXT NOT NULL,
          source_base_url TEXT,
          started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          finished_at TIMESTAMPTZ,
          listings_count INTEGER NOT NULL DEFAULT 0,
          blog_posts_count INTEGER NOT NULL DEFAULT 0,
          error_message TEXT
        );

        CREATE TABLE IF NOT EXISTS directoryiq_nodes (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          source_type TEXT NOT NULL,
          source_id TEXT NOT NULL,
          title TEXT,
          url TEXT,
          updated_at_source TIMESTAMPTZ,
          raw_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, source_type, source_id)
        );

        CREATE TABLE IF NOT EXISTS directoryiq_settings (
          user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
          vertical_override TEXT,
          risk_tier_overrides_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          image_style_preference TEXT NOT NULL DEFAULT 'editorial clean',
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE TABLE IF NOT EXISTS directoryiq_authority_posts (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          listing_source_id TEXT NOT NULL,
          slot_index INTEGER NOT NULL CHECK (slot_index >= 1 AND slot_index <= 4),
          post_type TEXT NOT NULL,
          focus_topic TEXT NOT NULL DEFAULT '',
          title TEXT,
          status TEXT NOT NULL DEFAULT 'not_created',
          draft_markdown TEXT,
          draft_html TEXT,
          featured_image_prompt TEXT,
          featured_image_url TEXT,
          published_post_id TEXT,
          published_url TEXT,
          blog_to_listing_link_status TEXT NOT NULL DEFAULT 'missing',
          listing_to_blog_link_status TEXT NOT NULL DEFAULT 'missing',
          metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, listing_source_id, slot_index)
        );

        CREATE INDEX IF NOT EXISTS idx_directoryiq_authority_posts_listing
          ON directoryiq_authority_posts(user_id, listing_source_id);

        CREATE TABLE IF NOT EXISTS directoryiq_versions (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          listing_source_id TEXT NOT NULL,
          authority_post_id UUID REFERENCES directoryiq_authority_posts(id) ON DELETE SET NULL,
          action_type TEXT NOT NULL,
          version_label TEXT NOT NULL,
          score_snapshot_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          content_delta_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          link_delta_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE INDEX IF NOT EXISTS idx_directoryiq_versions_user_created
          ON directoryiq_versions(user_id, created_at DESC);

        CREATE TABLE IF NOT EXISTS directoryiq_listing_upgrades (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          listing_source_id TEXT NOT NULL,
          created_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          original_description_hash TEXT NOT NULL,
          original_description TEXT NOT NULL DEFAULT '',
          proposed_description TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'draft',
          bd_update_ref TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          previewed_at TIMESTAMPTZ,
          pushed_at TIMESTAMPTZ
        );

        CREATE INDEX IF NOT EXISTS idx_directoryiq_listing_upgrades_listing
          ON directoryiq_listing_upgrades(user_id, listing_source_id, created_at DESC);

        CREATE TABLE IF NOT EXISTS brain_snapshots (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          brain_id TEXT NOT NULL,
          snapshot_json JSONB NOT NULL DEFAULT '[]'::jsonb,
          snapshot_status TEXT NOT NULL DEFAULT 'needs_connection',
          snapshot_updated_at TIMESTAMPTZ,
          hints_json JSONB NOT NULL DEFAULT '[]'::jsonb,
          last_error TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, brain_id)
        );

        CREATE TABLE IF NOT EXISTS snapshot_refresh_locks (
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          brain_id TEXT NOT NULL,
          locked_until TIMESTAMPTZ NOT NULL,
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          PRIMARY KEY (user_id, brain_id)
        );
      `),o=!0})().catch(e=>{throw N=null,e})),await N)}async function a(e,t=[]){return await s(),(await i().query(e,t)).rows}e.s(["query",()=>a]),T()}catch(e){T(e)}},!1),39719,e=>{"use strict";var t=e.i(54799);function T(){let e=process.env.INTEGRATIONS_ENCRYPTION_KEY??process.env.SERVER_ENCRYPTION_KEY;if(!e)throw Error("INTEGRATIONS_ENCRYPTION_KEY not configured");let t=e.trim();if(/^[0-9a-fA-F]{64}$/.test(t))return Buffer.from(t,"hex");let T=Buffer.from(t,"base64");if(32!==T.length)throw Error("INTEGRATIONS_ENCRYPTION_KEY must be 32 bytes (base64 or hex)");return T}function r(e,r){let E=T(),i=t.default.randomBytes(12),s=t.default.createCipheriv("aes-256-gcm",E,i);r&&s.setAAD(Buffer.from(r,"utf8"));let a=Buffer.concat([s.update(e,"utf8"),s.final()]),n=s.getAuthTag(),o={iv:i.toString("base64"),tag:n.toString("base64"),ciphertext:a.toString("base64")};return Buffer.from(JSON.stringify(o),"utf8").toString("base64")}function E(e,r){let E=T(),i=JSON.parse(Buffer.from(e,"base64").toString("utf8")),s=t.default.createDecipheriv("aes-256-gcm",E,Buffer.from(i.iv,"base64"));return r&&s.setAAD(Buffer.from(r,"utf8")),s.setAuthTag(Buffer.from(i.tag,"base64")),Buffer.concat([s.update(Buffer.from(i.ciphertext,"base64")),s.final()]).toString("utf8")}e.s(["decryptSecret",()=>E,"encryptSecret",()=>r])},28248,e=>e.a(async(t,T)=>{try{var r=e.i(39719),E=e.i(18669),i=t([E]);[E]=i.then?(await i)():i;let U="directoryiq",c=["brilliant_directories","openai","serpapi","ga4"];function s(e){return e&&"object"==typeof e?e:{}}function a(e){return c.includes(e)}function n(e){return e?`********${e}`:""}async function o(e){let t=await (0,E.query)(`
    SELECT provider, status, secret_last4, meta_json, saved_at, updated_at, secret_ciphertext, secret_iv, secret_tag
    FROM integrations_credentials
    WHERE user_id = $1 AND product = $2
    ORDER BY provider ASC
    `,[e,U]),T=new Map(t.map(e=>[e.provider,e]));return c.map(e=>{let t=T.get(e);return{provider:e,status:t?"connected":"disconnected",masked:t?n(t.secret_last4):"",savedAt:t?.saved_at??null,meta:s(t?.meta_json)}})}async function N(e,t){let T=(await (0,E.query)(`
    SELECT provider, status, secret_last4, meta_json, saved_at, updated_at, secret_ciphertext, secret_iv, secret_tag
    FROM integrations_credentials
    WHERE user_id = $1 AND product = $2 AND provider = $3
    LIMIT 1
    `,[e,U,t]))[0];return{provider:t,status:T?"connected":"disconnected",masked:T?n(T.secret_last4):"",savedAt:T?.saved_at??null,meta:s(T?.meta_json)}}async function L(e){let t=(0,r.encryptSecret)(e.secret,`${e.userId}:directoryiq:${e.provider}`),T=function(e){try{let t=JSON.parse(Buffer.from(e,"base64").toString("utf8"));if(!t.ciphertext)return{ciphertext:e,iv:null,tag:null};return{ciphertext:e,iv:t.iv??null,tag:t.tag??null}}catch{return{ciphertext:e,iv:null,tag:null}}}(t),i=e.secret.slice(-4);await (0,E.query)(`
    INSERT INTO integrations_credentials
    (user_id, product, provider, status, secret_ciphertext, secret_iv, secret_tag, secret_last4, meta_json, saved_at, updated_at)
    VALUES ($1, $2, $3, 'connected', $4, $5, $6, $7, $8::jsonb, now(), now())
    ON CONFLICT (user_id, product, provider)
    DO UPDATE SET
      status = 'connected',
      secret_ciphertext = EXCLUDED.secret_ciphertext,
      secret_iv = EXCLUDED.secret_iv,
      secret_tag = EXCLUDED.secret_tag,
      secret_last4 = EXCLUDED.secret_last4,
      meta_json = EXCLUDED.meta_json,
      saved_at = now(),
      updated_at = now()
    `,[e.userId,U,e.provider,T.ciphertext,T.iv,T.tag,i||null,JSON.stringify(e.meta??{})])}async function _(e,t){await (0,E.query)(`
    DELETE FROM integrations_credentials
    WHERE user_id = $1 AND product = $2 AND provider = $3
    `,[e,U,t])}async function d(e,t){let T=(await (0,E.query)(`
    SELECT secret_ciphertext, meta_json
    FROM integrations_credentials
    WHERE user_id = $1 AND product = $2 AND provider = $3
    LIMIT 1
    `,[e,U,t]))[0];return T?.secret_ciphertext?{secret:(0,r.decryptSecret)(T.secret_ciphertext,`${e}:directoryiq:${t}`),meta:s(T.meta_json)}:null}e.s(["deleteDirectoryIqIntegration",()=>_,"getDirectoryIqIntegration",()=>N,"getDirectoryIqIntegrationSecret",()=>d,"isDirectoryIqProvider",()=>a,"listDirectoryIqIntegrations",()=>o,"saveDirectoryIqIntegration",()=>L]),T()}catch(e){T(e)}},!1),68188,e=>{"use strict";function t(e){let t=e.trim();return t?t.replace(/\/+$/,""):""}async function T(e){try{let T=(e.method??"POST").toUpperCase(),r={"Content-Type":"application/x-www-form-urlencoded",Authorization:`Bearer ${e.apiKey}`},E=new URLSearchParams;for(let[t,T]of Object.entries(e.form??{}))null!=T&&E.set(t,String(T));let i=await fetch(`${t(e.baseUrl)}${e.path}`,{method:T,headers:r,body:"GET"===T?void 0:E,cache:"no-store"}),s=await i.text(),a=null;try{a=s?JSON.parse(s):null}catch{a=null}return{ok:i.ok,status:i.status,json:a,text:s}}catch(t){let e=t instanceof Error?t.message:"bd request failed";return{ok:!1,status:500,json:{error:e},text:e}}}async function r(e,t=2){let T=null;for(let r=1;r<=Math.max(1,t);r+=1){let t=await e();if(t.ok||t.status<500)return t;T=t}return T??{ok:!1,status:500,json:{error:"request failed"}}}function E(e){let t=e=>{let t=Number(e);return Number.isFinite(t)?t:null};return{status:"string"==typeof e.status?e.status:null,total:t(e.total??e.total_records??e.records_total),totalPages:t(e.total_pages??e.pages??e.last_page),page:t(e.page??e.current_page),limit:t(e.limit??e.per_page)}}function i(e){let t=e.data;if(Array.isArray(t))return t.filter(e=>!!e&&"object"==typeof e);if(t&&"object"==typeof t){let e=t.records??t.items??t.rows;if(Array.isArray(e))return e.filter(e=>!!e&&"object"==typeof e)}let T=e.records??e.items??e.rows;return Array.isArray(T)?T.filter(e=>!!e&&"object"==typeof e):[]}e.s(["bdRequestForm",()=>T,"bdRequestWithRetry",()=>r,"normalizeBdBaseUrl",()=>t,"parseBdRecords",()=>i,"parseBdTotals",()=>E])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__ab6f7df1._.js.map