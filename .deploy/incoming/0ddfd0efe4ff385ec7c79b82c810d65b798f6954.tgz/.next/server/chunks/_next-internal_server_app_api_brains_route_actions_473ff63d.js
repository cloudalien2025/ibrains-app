module.exports=[35734,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_brains_route_actions_473ff63d.js.map