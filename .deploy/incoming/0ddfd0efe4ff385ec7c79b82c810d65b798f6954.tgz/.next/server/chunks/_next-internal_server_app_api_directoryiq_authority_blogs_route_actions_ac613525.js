module.exports=[89682,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_directoryiq_authority_blogs_route_actions_ac613525.js.map