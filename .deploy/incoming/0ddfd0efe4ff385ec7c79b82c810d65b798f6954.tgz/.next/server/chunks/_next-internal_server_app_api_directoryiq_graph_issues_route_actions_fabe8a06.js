module.exports=[71827,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_directoryiq_graph_issues_route_actions_fabe8a06.js.map