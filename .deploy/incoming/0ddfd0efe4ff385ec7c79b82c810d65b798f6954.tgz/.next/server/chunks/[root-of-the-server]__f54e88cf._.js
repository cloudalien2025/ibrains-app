module.exports=[18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},23862,e=>e.a(async(t,r)=>{try{let t=await e.y("pg-587764f78a6c7a9c");e.n(t),r()}catch(e){r(e)}},!0),54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},18669,e=>e.a(async(t,r)=>{try{var T=e.i(23862),i=t([T]);[T]=i.then?(await i)():i;let n=null,o=!1,d=null;function E(){if(!n){let e=process.env.DATABASE_URL;if(!e)throw Error("DATABASE_URL not configured");n=new T.Pool({connectionString:e})}return n}async function s(){o||(d||(d=(async()=>{let e=E();await e.query(`
        CREATE EXTENSION IF NOT EXISTS pgcrypto;

        CREATE TABLE IF NOT EXISTS users (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          external_id TEXT UNIQUE,
          email TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE TABLE IF NOT EXISTS integrations (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          provider TEXT NOT NULL,
          shop_domain TEXT NOT NULL,
          access_token_ciphertext TEXT NOT NULL,
          scopes TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'connected',
          installed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          last_verified_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, provider, shop_domain)
        );

        CREATE TABLE IF NOT EXISTS oauth_states (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          provider TEXT NOT NULL,
          shop_domain TEXT NOT NULL,
          state TEXT NOT NULL UNIQUE,
          expires_at TIMESTAMPTZ NOT NULL,
          used_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE TABLE IF NOT EXISTS ingest_runs (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
          status TEXT NOT NULL,
          started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          finished_at TIMESTAMPTZ,
          products_count INTEGER NOT NULL DEFAULT 0,
          articles_count INTEGER NOT NULL DEFAULT 0,
          pages_count INTEGER NOT NULL DEFAULT 0,
          collections_count INTEGER NOT NULL DEFAULT 0,
          error_message TEXT
        );

        CREATE TABLE IF NOT EXISTS site_nodes (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
          node_type TEXT NOT NULL,
          source_id TEXT NOT NULL,
          handle TEXT,
          title TEXT NOT NULL,
          url TEXT,
          tags JSONB NOT NULL DEFAULT '[]',
          body_text TEXT,
          body_html TEXT,
          image_url TEXT,
          published_at TIMESTAMPTZ,
          updated_at_source TIMESTAMPTZ,
          raw_json JSONB NOT NULL DEFAULT '{}',
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (integration_id, source_id)
        );

        CREATE INDEX IF NOT EXISTS idx_site_nodes_integration_type
          ON site_nodes(integration_id, node_type);

        CREATE TABLE IF NOT EXISTS product_blog_links (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
          product_node_id UUID NOT NULL REFERENCES site_nodes(id) ON DELETE CASCADE,
          article_node_id UUID NOT NULL REFERENCES site_nodes(id) ON DELETE CASCADE,
          score NUMERIC NOT NULL,
          reason TEXT NOT NULL,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (product_node_id, article_node_id)
        );

        CREATE TABLE IF NOT EXISTS byo_api_keys (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          provider TEXT NOT NULL,
          key_ciphertext TEXT NOT NULL,
          key_last4 TEXT,
          key_length INTEGER,
          label TEXT,
          last_verified_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, provider)
        );

        ALTER TABLE byo_api_keys
          ADD COLUMN IF NOT EXISTS key_last4 TEXT;

        ALTER TABLE byo_api_keys
          ADD COLUMN IF NOT EXISTS key_length INTEGER;

        ALTER TABLE byo_api_keys
          ADD COLUMN IF NOT EXISTS last_verified_at TIMESTAMPTZ;

        CREATE TABLE IF NOT EXISTS directoryiq_signal_source_credentials (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          connector_id TEXT NOT NULL,
          secret_ciphertext TEXT NOT NULL,
          secret_last4 TEXT,
          secret_length INTEGER,
          label TEXT,
          config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          last_verified_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, connector_id)
        );

        CREATE TABLE IF NOT EXISTS integrations_credentials (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          product TEXT NOT NULL,
          provider TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'connected',
          secret_ciphertext TEXT,
          secret_iv TEXT,
          secret_tag TEXT,
          secret_last4 TEXT,
          meta_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          saved_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, product, provider)
        );

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'connected';

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_ciphertext TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_iv TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_tag TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_last4 TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS meta_json JSONB NOT NULL DEFAULT '{}'::jsonb;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS saved_at TIMESTAMPTZ NOT NULL DEFAULT now();

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS secret_last4 TEXT;

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS secret_length INTEGER;

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS last_verified_at TIMESTAMPTZ;

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS config_json JSONB NOT NULL DEFAULT '{}'::jsonb;

        CREATE TABLE IF NOT EXISTS directoryiq_ingest_runs (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          status TEXT NOT NULL,
          source_base_url TEXT,
          started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          finished_at TIMESTAMPTZ,
          listings_count INTEGER NOT NULL DEFAULT 0,
          blog_posts_count INTEGER NOT NULL DEFAULT 0,
          error_message TEXT
        );

        CREATE TABLE IF NOT EXISTS directoryiq_nodes (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          source_type TEXT NOT NULL,
          source_id TEXT NOT NULL,
          title TEXT,
          url TEXT,
          updated_at_source TIMESTAMPTZ,
          raw_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, source_type, source_id)
        );

        CREATE TABLE IF NOT EXISTS directoryiq_settings (
          user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
          vertical_override TEXT,
          risk_tier_overrides_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          image_style_preference TEXT NOT NULL DEFAULT 'editorial clean',
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE TABLE IF NOT EXISTS directoryiq_authority_posts (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          listing_source_id TEXT NOT NULL,
          slot_index INTEGER NOT NULL CHECK (slot_index >= 1 AND slot_index <= 4),
          post_type TEXT NOT NULL,
          focus_topic TEXT NOT NULL DEFAULT '',
          title TEXT,
          status TEXT NOT NULL DEFAULT 'not_created',
          draft_markdown TEXT,
          draft_html TEXT,
          featured_image_prompt TEXT,
          featured_image_url TEXT,
          published_post_id TEXT,
          published_url TEXT,
          blog_to_listing_link_status TEXT NOT NULL DEFAULT 'missing',
          listing_to_blog_link_status TEXT NOT NULL DEFAULT 'missing',
          metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, listing_source_id, slot_index)
        );

        CREATE INDEX IF NOT EXISTS idx_directoryiq_authority_posts_listing
          ON directoryiq_authority_posts(user_id, listing_source_id);

        CREATE TABLE IF NOT EXISTS directoryiq_versions (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          listing_source_id TEXT NOT NULL,
          authority_post_id UUID REFERENCES directoryiq_authority_posts(id) ON DELETE SET NULL,
          action_type TEXT NOT NULL,
          version_label TEXT NOT NULL,
          score_snapshot_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          content_delta_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          link_delta_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE INDEX IF NOT EXISTS idx_directoryiq_versions_user_created
          ON directoryiq_versions(user_id, created_at DESC);

        CREATE TABLE IF NOT EXISTS directoryiq_listing_upgrades (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          listing_source_id TEXT NOT NULL,
          created_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          original_description_hash TEXT NOT NULL,
          original_description TEXT NOT NULL DEFAULT '',
          proposed_description TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'draft',
          bd_update_ref TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          previewed_at TIMESTAMPTZ,
          pushed_at TIMESTAMPTZ
        );

        CREATE INDEX IF NOT EXISTS idx_directoryiq_listing_upgrades_listing
          ON directoryiq_listing_upgrades(user_id, listing_source_id, created_at DESC);

        CREATE TABLE IF NOT EXISTS brain_snapshots (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          brain_id TEXT NOT NULL,
          snapshot_json JSONB NOT NULL DEFAULT '[]'::jsonb,
          snapshot_status TEXT NOT NULL DEFAULT 'needs_connection',
          snapshot_updated_at TIMESTAMPTZ,
          hints_json JSONB NOT NULL DEFAULT '[]'::jsonb,
          last_error TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, brain_id)
        );

        CREATE TABLE IF NOT EXISTS snapshot_refresh_locks (
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          brain_id TEXT NOT NULL,
          locked_until TIMESTAMPTZ NOT NULL,
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          PRIMARY KEY (user_id, brain_id)
        );
      `),o=!0})().catch(e=>{throw d=null,e})),await d)}async function a(e,t=[]){return await s(),(await E().query(e,t)).rows}e.s(["query",()=>a]),r()}catch(e){r(e)}},!1),23203,e=>e.a(async(t,r)=>{try{var T=e.i(54799),i=e.i(18669),E=t([i]);[i]=E.then?(await E)():E;let o="00000000-0000-4000-8000-000000000001";function s(e){if(!e)return null;let t=e.trim().toLowerCase();return/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(t)?t:null}function a(e){if(!e)return o;let t=s(e.headers.get("x-user-id"));if(t)return t;let r=s(e.nextUrl.searchParams.get("user_id"));if(r)return r;let i=e.headers.get("x-user-id")??e.headers.get("x-user-email")??e.headers.get("x-forwarded-email")??e.headers.get("cf-access-authenticated-user-email");if(i&&i.trim().length>0){let e,t,r;return e=T.default.createHash("sha256").update(i.trim().toLowerCase()).digest(),(t=Buffer.from(e.subarray(0,16)))[6]=15&t[6]|64,t[8]=63&t[8]|128,r=t.toString("hex"),`${r.slice(0,8)}-${r.slice(8,12)}-${r.slice(12,16)}-${r.slice(16,20)}-${r.slice(20,32)}`}return o}async function n(e){await (0,i.query)(`
    INSERT INTO users (id, external_id, email)
    VALUES ($1, $2, $3)
    ON CONFLICT (id) DO NOTHING
    `,[e,`local:${e}`,null])}e.s(["ensureUser",()=>n,"resolveUserId",()=>a]),r()}catch(e){r(e)}},!1),56311,e=>e.a(async(t,r)=>{try{var T=e.i(89171),i=e.i(18669),E=e.i(23203),s=t([i,E]);async function a(e){try{let t=(0,E.resolveUserId)(e);await (0,E.ensureUser)(t);let r=await (0,i.query)(`
      SELECT id, status, source_base_url, started_at, finished_at, listings_count, blog_posts_count, error_message
      FROM directoryiq_ingest_runs
      WHERE user_id = $1
      ORDER BY started_at DESC
      LIMIT 10
      `,[t]);return T.NextResponse.json({runs:r})}catch(t){let e=t instanceof Error?t.message:"Unknown DirectoryIQ runs error";return T.NextResponse.json({error:e},{status:500})}}[i,E]=s.then?(await s)():s,e.s(["GET",()=>a,"runtime",0,"nodejs"]),r()}catch(e){r(e)}},!1),29305,e=>e.a(async(t,r)=>{try{var T=e.i(47909),i=e.i(74017),E=e.i(96250),s=e.i(59756),a=e.i(61916),n=e.i(74677),o=e.i(69741),d=e.i(16795),N=e.i(87718),L=e.i(95169),_=e.i(47587),u=e.i(66012),U=e.i(70101),l=e.i(26937),c=e.i(10372),A=e.i(93695);e.i(52474);var O=e.i(220),p=e.i(56311),I=t([p]);[p]=I.then?(await I)():I;let R=new T.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/directoryiq/ingest/runs/route",pathname:"/api/directoryiq/ingest/runs",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/directoryiq/ingest/runs/route.ts",nextConfigOutput:"",userland:p}),{workAsyncStorage:C,workUnitAsyncStorage:g,serverHooks:F}=R;function D(){return(0,E.patchFetch)({workAsyncStorage:C,workUnitAsyncStorage:g})}async function S(e,t,r){R.isDev&&(0,s.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let T="/api/directoryiq/ingest/runs/route";T=T.replace(/\/index$/,"")||"/";let E=await R.prepare(e,t,{srcPage:T,multiZoneDraftMode:!1});if(!E)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:p,params:I,nextConfig:D,parsedUrl:S,isDraftMode:C,prerenderManifest:g,routerServerContext:F,isOnDemandRevalidate:M,revalidateOnlyGenerated:h,resolvedPathname:X,clientReferenceManifest:y,serverActionsManifest:w}=E,x=(0,o.normalizeAppPath)(T),f=!!(g.dynamicRoutes[x]||g.routes[X]),m=async()=>((null==F?void 0:F.render404)?await F.render404(e,t,S,!1):t.end("This page could not be found"),null);if(f&&!C){let e=!!g.routes[X],t=g.dynamicRoutes[x];if(t&&!1===t.fallback&&!e){if(D.experimental.adapterPath)return await m();throw new A.NoFallbackError}}let P=null;!f||R.isDev||C||(P=X,P="/index"===P?"/":P);let v=!0===R.isDev||!f,b=f&&!v;w&&y&&(0,n.setManifestsSingleton)({page:T,clientReferenceManifest:y,serverActionsManifest:w});let B=e.method||"GET",q=(0,a.getTracer)(),j=q.getActiveScopeSpan(),Z={params:I,prerenderManifest:g,renderOpts:{experimental:{authInterrupts:!!D.experimental.authInterrupts},cacheComponents:!!D.cacheComponents,supportsDynamicResponse:v,incrementalCache:(0,s.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:D.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,T,i)=>R.onRequestError(e,t,T,i,F)},sharedContext:{buildId:p}},k=new d.NodeNextRequest(e),Y=new d.NodeNextResponse(t),K=N.NextRequestAdapter.fromNodeNextRequest(k,(0,N.signalFromNodeResponse)(t));try{let E=async e=>R.handle(K,Z).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=q.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==L.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=r.get("next.route");if(i){let t=`${B} ${i}`;e.setAttributes({"next.route":i,"http.route":i,"next.span_name":t}),e.updateName(t)}else e.updateName(`${B} ${T}`)}),n=!!(0,s.getRequestMeta)(e,"minimalMode"),o=async s=>{var a,o;let d=async({previousCacheEntry:i})=>{try{if(!n&&M&&h&&!i)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let T=await E(s);e.fetchMetrics=Z.renderOpts.fetchMetrics;let a=Z.renderOpts.pendingWaitUntil;a&&r.waitUntil&&(r.waitUntil(a),a=void 0);let o=Z.renderOpts.collectedTags;if(!f)return await (0,u.sendResponse)(k,Y,T,Z.renderOpts.pendingWaitUntil),null;{let e=await T.blob(),t=(0,U.toNodeOutgoingHttpHeaders)(T.headers);o&&(t[c.NEXT_CACHE_TAGS_HEADER]=o),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==Z.renderOpts.collectedRevalidate&&!(Z.renderOpts.collectedRevalidate>=c.INFINITE_CACHE)&&Z.renderOpts.collectedRevalidate,i=void 0===Z.renderOpts.collectedExpire||Z.renderOpts.collectedExpire>=c.INFINITE_CACHE?void 0:Z.renderOpts.collectedExpire;return{value:{kind:O.CachedRouteKind.APP_ROUTE,status:T.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:i}}}}catch(t){throw(null==i?void 0:i.isStale)&&await R.onRequestError(e,t,{routerKind:"App Router",routePath:T,routeType:"route",revalidateReason:(0,_.getRevalidateReason)({isStaticGeneration:b,isOnDemandRevalidate:M})},!1,F),t}},N=await R.handleResponse({req:e,nextConfig:D,cacheKey:P,routeKind:i.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:g,isRoutePPREnabled:!1,isOnDemandRevalidate:M,revalidateOnlyGenerated:h,responseGenerator:d,waitUntil:r.waitUntil,isMinimalMode:n});if(!f)return null;if((null==N||null==(a=N.value)?void 0:a.kind)!==O.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==N||null==(o=N.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});n||t.setHeader("x-nextjs-cache",M?"REVALIDATED":N.isMiss?"MISS":N.isStale?"STALE":"HIT"),C&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let L=(0,U.fromNodeOutgoingHttpHeaders)(N.value.headers);return n&&f||L.delete(c.NEXT_CACHE_TAGS_HEADER),!N.cacheControl||t.getHeader("Cache-Control")||L.get("Cache-Control")||L.set("Cache-Control",(0,l.getCacheControlHeader)(N.cacheControl)),await (0,u.sendResponse)(k,Y,new Response(N.value.body,{headers:L,status:N.value.status||200})),null};j?await o(j):await q.withPropagatedContext(e.headers,()=>q.trace(L.BaseServerSpan.handleRequest,{spanName:`${B} ${T}`,kind:a.SpanKind.SERVER,attributes:{"http.method":B,"http.target":e.url}},o))}catch(t){if(t instanceof A.NoFallbackError||await R.onRequestError(e,t,{routerKind:"App Router",routePath:x,routeType:"route",revalidateReason:(0,_.getRevalidateReason)({isStaticGeneration:b,isOnDemandRevalidate:M})},!1,F),f)throw t;return await (0,u.sendResponse)(k,Y,new Response(null,{status:500})),null}}e.s(["handler",()=>S,"patchFetch",()=>D,"routeModule",()=>R,"serverHooks",()=>F,"workAsyncStorage",()=>C,"workUnitAsyncStorage",()=>g]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__f54e88cf._.js.map