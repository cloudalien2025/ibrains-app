module.exports=[18622,(t,e,i)=>{e.exports=t.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(t,e,i)=>{e.exports=t.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(t,e,i)=>{e.exports=t.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(t,e,i)=>{e.exports=t.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},83813,t=>{"use strict";function e(t,e,i){return Math.max(e,Math.min(i,t))}function i(t,e){let i=`${t} ${e.join(" ")}`.toLowerCase();return/(hotel|restaurant|travel|tour|hospitality|resort)/.test(i)?"hospitality-travel":/(medical|dental|clinic|health)/.test(i)?"health-medical":/(law|legal|attorney|finance|accounting|tax)/.test(i)?"legal-financial":/(school|education|training|academy)/.test(i)?"education":/(home|plumb|electric|roof|contractor|service)/.test(i)?"home-services":"general"}function r(t){let i=t.riskTierOverride??"medium",r=e(60+3*t.schemaSignals.length+t.taxonomySignals.length,0,100),a=e(60+10*!!t.description+5*!!t.ctaText,0,100),s=e(50+5*t.credentialsSignals.length+4*t.evidenceSignals.length+Math.round((t.averageRating??0)*4)+Math.min(10,t.reviewCount/10),0,100),n=e(50+10*t.authorityPosts.filter(t=>"published"===t.status).length+5*t.authorityPosts.filter(t=>t.blogToListingLinked&&t.listingToBlogLinked).length,0,100),o=e(55+8*!!t.contact+8*!!t.ctaText,0,100),l="high"===i?90:100,u="high"===i?92:100,d=Math.min(n,l),c=Math.min(s,u),_=Math.round((r+a+c+d+o)/5);return{listingId:t.listingId,vertical:t.vertical,riskTier:i,totalScore:_,scores:{structure:r,clarity:a,trust:c,authority:d,actionability:o},caps:{authorityCap:l,trustCap:u}}}function a(t){if(0===t.length)return{readiness:0,pillars:{structure:0,clarity:0,trust:0,authority:0,actionability:0}};let e=t.reduce((t,e)=>(t.structure+=e.scores.structure,t.clarity+=e.scores.clarity,t.trust+=e.scores.trust,t.authority+=e.scores.authority,t.actionability+=e.scores.actionability,t.total+=e.totalScore,t),{structure:0,clarity:0,trust:0,authority:0,actionability:0,total:0}),i=t.length;return{readiness:Math.round(e.total/i),pillars:{structure:Math.round(e.structure/i),clarity:Math.round(e.clarity/i),trust:Math.round(e.trust/i),authority:Math.round(e.authority/i),actionability:Math.round(e.actionability/i)}}}t.s(["computeSiteReadiness",()=>a,"detectVerticalFromSignals",()=>i,"evaluateListingSelection",()=>r])},28239,t=>t.a(async(e,i)=>{try{var r=t.i(18669),a=t.i(28248);t.i(54799);var s=t.i(83813),n=e([r,a]);function o(t,e,i){return Math.min(i,Math.max(e,t))}function l(t){return"string"==typeof t?t:""}function u(t){return Array.isArray(t)?t.filter(t=>"string"==typeof t):[]}function d(t,e,i){let r=t.raw_json??{},a=t.title??l(r.title)??t.source_id,n=l(r.group_desc)||l(r.short_description)||l(r.description)||l(r.content)||l(r.content?.rendered)||l(r.excerpt),d=l(r.group_category)||l(r.category)||l(r.category_name)||l(r.primary_category?.name),c=l(r.post_location)||l(r.location)||l(r.city)||l(r.address)||l(r.service_area),_=l(r.phone)||l(r.phone1)||l(r.email)||l(r.contact)||l(r.website),p=l(r.cta)||l(r.call_to_action)||l(r.booking_url)||l(r.contact_url),g=[...u(r.schema_types)??[],...r.structured_data?["structured_data"]:[],...r.schema_mapping?["schema_mapping"]:[]],h=[d,...u(r.tags),...u(r.categories),...u(r.taxonomy_terms)].filter(Boolean),y=[l(r.license),l(r.certification),l(r.accreditation)].filter(Boolean),m=[l(r.case_studies),l(r.testimonials),l(r.portfolio),l(r.years_in_business)].filter(Boolean),f=[l(r.business_name),l(r.nap_name),l(r.nap_phone),l(r.nap_address)].filter(Boolean),v=Number(r.review_count??r.reviews_count??0)||0,E=r.average_rating??r.rating??null,R=(0,s.detectVerticalFromSignals)(d,h),w=i.verticalOverride??R,b=i.riskTierOverrides[w]??null,x=e.map(t=>{var e;let i=(t.metadata_json??{}).quality_score,r="number"==typeof i?o(i,0,100):"published"===t.status?78:55*("draft"===t.status);return{slot:t.slot_index,type:(e=t.post_type,"comparison"===e||"best_of"===e||"contextual_guide"===e||"persona_intent"===e?e:"contextual_guide"),status:t.status,focusTopic:t.focus_topic,title:t.title??"",qualityScore:r,blogToListingLinked:"linked"===t.blog_to_listing_link_status,listingToBlogLinked:"linked"===t.listing_to_blog_link_status}}),S=Number(r.cluster_density??.3),T=Number(r.orphan_risk??.5);return{listingId:t.source_id,title:a,description:n,category:d,location:c,contact:_,ctaText:p,schemaSignals:g,taxonomySignals:h,credentialsSignals:y,reviewCount:v,averageRating:"number"==typeof E?E:null,evidenceSignals:m,identitySignals:f,internalMentionsCount:Number(r.internal_mentions_count??0),clusterDensity:Number.isFinite(S)?o(S,0,1):.3,orphanRisk:Number.isFinite(T)?o(T,0,1):.5,vertical:w,riskTierOverride:b,authorityPosts:x}}async function c(t){let e=(await (0,r.query)(`
    SELECT vertical_override, risk_tier_overrides_json, image_style_preference, updated_at
    FROM directoryiq_settings
    WHERE user_id = $1
    LIMIT 1
    `,[t]))[0];if(!e)return{verticalOverride:null,riskTierOverrides:{},imageStylePreference:"editorial clean",updatedAt:null};let i={},a=e.risk_tier_overrides_json??{};for(let[t,e]of Object.entries(a))("home-services"===t||"health-medical"===t||"legal-financial"===t||"hospitality-travel"===t||"education"===t||"general"===t)&&("low"===e||"medium"===e||"high"===e)&&(i[t]=e);let s=e.vertical_override;return{verticalOverride:"home-services"===s||"health-medical"===s||"legal-financial"===s||"hospitality-travel"===s||"education"===s||"general"===s?s:null,riskTierOverrides:i,imageStylePreference:e.image_style_preference?.trim()||"editorial clean",updatedAt:e.updated_at}}async function _(t,e){let i=["comparison","best_of","contextual_guide","persona_intent"];for(let a=0;a<4;a+=1){let s=a+1;await (0,r.query)(`
      INSERT INTO directoryiq_authority_posts
      (user_id, listing_source_id, slot_index, post_type, focus_topic, status)
      VALUES ($1, $2, $3, $4, $5, 'not_created')
      ON CONFLICT (user_id, listing_source_id, slot_index)
      DO NOTHING
      `,[t,e,s,i[a],""])}}async function p(t,e){return await _(t,e),await (0,r.query)(`
    SELECT
      id,
      listing_source_id,
      slot_index,
      post_type,
      focus_topic,
      title,
      status,
      draft_markdown,
      draft_html,
      featured_image_prompt,
      featured_image_url,
      published_post_id,
      published_url,
      blog_to_listing_link_status,
      listing_to_blog_link_status,
      metadata_json,
      updated_at
    FROM directoryiq_authority_posts
    WHERE user_id = $1 AND listing_source_id = $2
    ORDER BY slot_index ASC
    `,[t,e])}async function g(t,e,i){return await _(t,e),(await (0,r.query)(`
    SELECT
      id,
      listing_source_id,
      slot_index,
      post_type,
      focus_topic,
      title,
      status,
      draft_markdown,
      draft_html,
      featured_image_prompt,
      featured_image_url,
      published_post_id,
      published_url,
      blog_to_listing_link_status,
      listing_to_blog_link_status,
      metadata_json,
      updated_at
    FROM directoryiq_authority_posts
    WHERE user_id = $1 AND listing_source_id = $2 AND slot_index = $3
    LIMIT 1
    `,[t,e,i]))[0]??null}async function h(t){let e=await c(t),i=await (0,r.query)(`
    SELECT source_id, title, url, updated_at, raw_json
    FROM directoryiq_nodes
    WHERE user_id = $1 AND source_type = 'listing'
    ORDER BY updated_at DESC
    `,[t]),a=i.map(t=>t.source_id),n=[];a.length>0&&(n=await (0,r.query)(`
      SELECT
        id,
        listing_source_id,
        slot_index,
        post_type,
        focus_topic,
        title,
        status,
        draft_markdown,
        draft_html,
        featured_image_prompt,
        featured_image_url,
        published_post_id,
        published_url,
        blog_to_listing_link_status,
        listing_to_blog_link_status,
        metadata_json,
        updated_at
      FROM directoryiq_authority_posts
      WHERE user_id = $1 AND listing_source_id = ANY($2::text[])
      ORDER BY listing_source_id, slot_index ASC
      `,[t,a]));let o=new Map;for(let t of n){let e=o.get(t.listing_source_id)??[];e.push(t),o.set(t.listing_source_id,e)}let l=[],u=[];for(let t of i){let i=o.get(t.source_id)??[],r=d(t,i,e),a=(0,s.evaluateListingSelection)(r);l.push(a),u.push({listingId:t.source_id,name:t.title??t.source_id,url:t.url,authorityStatus:a.scores.authority>=70?"Strong":"Needs Support",trustStatus:a.scores.trust>=70?"Strong":"Needs Trust",lastOptimized:i.some(t=>"published"===t.status)?t.updated_at:null,evaluation:a})}let _=(0,s.computeSiteReadiness)(l),p=e.verticalOverride??u[0]?.evaluation.vertical??"general";return{cards:u,readiness:_.readiness,pillarAverages:_.pillars,verticalDetected:p}}async function y(t,e){let i=await c(t),a=(await (0,r.query)(`
    SELECT source_id, title, url, updated_at, raw_json
    FROM directoryiq_nodes
    WHERE user_id = $1 AND source_type = 'listing' AND source_id = $2
    LIMIT 1
    `,[t,e]))[0]??null;if(!a)return{listing:null,authorityPosts:[],evaluation:null,settings:i};let n=await p(t,a.source_id),o=d(a,n,i),l=(0,s.evaluateListingSelection)(o);return{listing:a,authorityPosts:n,evaluation:l,settings:i}}async function m(t,e,i,a){await (0,r.query)(`
    INSERT INTO directoryiq_authority_posts
    (user_id, listing_source_id, slot_index, post_type, focus_topic, title, status, draft_markdown, draft_html, blog_to_listing_link_status, metadata_json, updated_at)
    VALUES ($1, $2, $3, $4, $5, $6, 'draft', $7, $8, $9, $10::jsonb, now())
    ON CONFLICT (user_id, listing_source_id, slot_index)
    DO UPDATE SET
      post_type = EXCLUDED.post_type,
      focus_topic = EXCLUDED.focus_topic,
      title = EXCLUDED.title,
      status = 'draft',
      draft_markdown = EXCLUDED.draft_markdown,
      draft_html = EXCLUDED.draft_html,
      blog_to_listing_link_status = EXCLUDED.blog_to_listing_link_status,
      metadata_json = EXCLUDED.metadata_json,
      updated_at = now()
    `,[t,e,i,a.type,a.focusTopic,a.title,a.draftMarkdown,a.draftHtml,a.blogToListingStatus,JSON.stringify(a.metadata)])}async function f(t,e,i,a){await (0,r.query)(`
    UPDATE directoryiq_authority_posts
    SET
      featured_image_prompt = $4,
      featured_image_url = $5,
      updated_at = now()
    WHERE user_id = $1 AND listing_source_id = $2 AND slot_index = $3
    `,[t,e,i,a.imagePrompt,a.imageUrl])}async function v(t,e,i,a){await (0,r.query)(`
    UPDATE directoryiq_authority_posts
    SET
      status = 'published',
      published_post_id = $4,
      published_url = $5,
      blog_to_listing_link_status = $6,
      listing_to_blog_link_status = $7,
      metadata_json = $8::jsonb,
      updated_at = now()
    WHERE user_id = $1 AND listing_source_id = $2 AND slot_index = $3
    `,[t,e,i,a.publishedPostId,a.publishedUrl,a.blogToListingStatus,a.listingToBlogStatus,JSON.stringify(a.metadata)])}async function E(t,e){return(await (0,r.query)(`
    INSERT INTO directoryiq_versions
    (user_id, listing_source_id, authority_post_id, action_type, version_label, score_snapshot_json, content_delta_json, link_delta_json)
    VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8::jsonb)
    RETURNING id
    `,[t,e.listingId,e.authorityPostId??null,e.actionType,e.versionLabel,JSON.stringify(e.scoreSnapshot),JSON.stringify(e.contentDelta),JSON.stringify(e.linkDelta)]))[0].id}[r,a]=n.then?(await n)():n,t.s(["addDirectoryIqVersion",()=>E,"getAllListingsWithEvaluations",()=>h,"getAuthorityPostBySlot",()=>g,"getDirectoryIqSettings",()=>c,"getListingEvaluation",()=>y,"markPostPublished",()=>v,"saveAuthorityImage",()=>f,"upsertAuthorityPostDraft",()=>m]),i()}catch(t){i(t)}},!1),87162,t=>t.a(async(e,i)=>{try{var r=t.i(89171),a=t.i(23203),s=t.i(28239),n=e([a,s]);async function o(t){try{let e=(0,a.resolveUserId)(t);await (0,a.ensureUser)(e);let i=await (0,s.getAllListingsWithEvaluations)(e),n=i.cards.map(t=>({listing_id:t.listingId,listing_name:t.name,url:t.url,score:t.evaluation.totalScore,pillars:t.evaluation.scores,authority_status:t.authorityStatus.toLowerCase().replace(/\s+/g,"_"),trust_status:t.trustStatus.toLowerCase().replace(/\s+/g,"_"),last_optimized:t.lastOptimized}));return r.NextResponse.json({ok:!0,listings:n,readiness:i.readiness,pillar_averages:i.pillarAverages,vertical_detected:i.verticalDetected})}catch(e){let t=e instanceof Error?e.message:"Failed to load listings";return r.NextResponse.json({ok:!1,listings:[],error:t},{status:500})}}[a,s]=n.then?(await n)():n,t.s(["GET",()=>o,"runtime",0,"nodejs"]),i()}catch(t){i(t)}},!1),1285,t=>t.a(async(e,i)=>{try{var r=t.i(47909),a=t.i(74017),s=t.i(96250),n=t.i(59756),o=t.i(61916),l=t.i(74677),u=t.i(69741),d=t.i(16795),c=t.i(87718),_=t.i(95169),p=t.i(47587),g=t.i(66012),h=t.i(70101),y=t.i(26937),m=t.i(10372),f=t.i(93695);t.i(52474);var v=t.i(220),E=t.i(87162),R=e([E]);[E]=R.then?(await R)():R;let x=new r.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/directoryiq/listings/route",pathname:"/api/directoryiq/listings",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/directoryiq/listings/route.ts",nextConfigOutput:"",userland:E}),{workAsyncStorage:S,workUnitAsyncStorage:T,serverHooks:N}=x;function w(){return(0,s.patchFetch)({workAsyncStorage:S,workUnitAsyncStorage:T})}async function b(t,e,i){x.isDev&&(0,n.addRequestMeta)(t,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/directoryiq/listings/route";r=r.replace(/\/index$/,"")||"/";let s=await x.prepare(t,e,{srcPage:r,multiZoneDraftMode:!1});if(!s)return e.statusCode=400,e.end("Bad Request"),null==i.waitUntil||i.waitUntil.call(i,Promise.resolve()),null;let{buildId:E,params:R,nextConfig:w,parsedUrl:b,isDraftMode:S,prerenderManifest:T,routerServerContext:N,isOnDemandRevalidate:A,revalidateOnlyGenerated:C,resolvedPathname:k,clientReferenceManifest:$,serverActionsManifest:O}=s,D=(0,u.normalizeAppPath)(r),q=!!(T.dynamicRoutes[D]||T.routes[k]),L=async()=>((null==N?void 0:N.render404)?await N.render404(t,e,b,!1):e.end("This page could not be found"),null);if(q&&!S){let t=!!T.routes[k],e=T.dynamicRoutes[D];if(e&&!1===e.fallback&&!t){if(w.experimental.adapterPath)return await L();throw new f.NoFallbackError}}let I=null;!q||x.isDev||S||(I=k,I="/index"===I?"/":I);let j=!0===x.isDev||!q,M=q&&!j;O&&$&&(0,l.setManifestsSingleton)({page:r,clientReferenceManifest:$,serverActionsManifest:O});let P=t.method||"GET",U=(0,o.getTracer)(),H=U.getActiveScopeSpan(),F={params:R,prerenderManifest:T,renderOpts:{experimental:{authInterrupts:!!w.experimental.authInterrupts},cacheComponents:!!w.cacheComponents,supportsDynamicResponse:j,incrementalCache:(0,n.getRequestMeta)(t,"incrementalCache"),cacheLifeProfiles:w.cacheLife,waitUntil:i.waitUntil,onClose:t=>{e.on("close",t)},onAfterTaskError:void 0,onInstrumentationRequestError:(e,i,r,a)=>x.onRequestError(t,e,r,a,N)},sharedContext:{buildId:E}},B=new d.NodeNextRequest(t),W=new d.NodeNextResponse(e),X=c.NextRequestAdapter.fromNodeNextRequest(B,(0,c.signalFromNodeResponse)(e));try{let s=async t=>x.handle(X,F).finally(()=>{if(!t)return;t.setAttributes({"http.status_code":e.statusCode,"next.rsc":!1});let i=U.getRootSpanAttributes();if(!i)return;if(i.get("next.span_type")!==_.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${i.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=i.get("next.route");if(a){let e=`${P} ${a}`;t.setAttributes({"next.route":a,"http.route":a,"next.span_name":e}),t.updateName(e)}else t.updateName(`${P} ${r}`)}),l=!!(0,n.getRequestMeta)(t,"minimalMode"),u=async n=>{var o,u;let d=async({previousCacheEntry:a})=>{try{if(!l&&A&&C&&!a)return e.statusCode=404,e.setHeader("x-nextjs-cache","REVALIDATED"),e.end("This page could not be found"),null;let r=await s(n);t.fetchMetrics=F.renderOpts.fetchMetrics;let o=F.renderOpts.pendingWaitUntil;o&&i.waitUntil&&(i.waitUntil(o),o=void 0);let u=F.renderOpts.collectedTags;if(!q)return await (0,g.sendResponse)(B,W,r,F.renderOpts.pendingWaitUntil),null;{let t=await r.blob(),e=(0,h.toNodeOutgoingHttpHeaders)(r.headers);u&&(e[m.NEXT_CACHE_TAGS_HEADER]=u),!e["content-type"]&&t.type&&(e["content-type"]=t.type);let i=void 0!==F.renderOpts.collectedRevalidate&&!(F.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&F.renderOpts.collectedRevalidate,a=void 0===F.renderOpts.collectedExpire||F.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:F.renderOpts.collectedExpire;return{value:{kind:v.CachedRouteKind.APP_ROUTE,status:r.status,body:Buffer.from(await t.arrayBuffer()),headers:e},cacheControl:{revalidate:i,expire:a}}}}catch(e){throw(null==a?void 0:a.isStale)&&await x.onRequestError(t,e,{routerKind:"App Router",routePath:r,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:A})},!1,N),e}},c=await x.handleResponse({req:t,nextConfig:w,cacheKey:I,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:T,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:C,responseGenerator:d,waitUntil:i.waitUntil,isMinimalMode:l});if(!q)return null;if((null==c||null==(o=c.value)?void 0:o.kind)!==v.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==c||null==(u=c.value)?void 0:u.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});l||e.setHeader("x-nextjs-cache",A?"REVALIDATED":c.isMiss?"MISS":c.isStale?"STALE":"HIT"),S&&e.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let _=(0,h.fromNodeOutgoingHttpHeaders)(c.value.headers);return l&&q||_.delete(m.NEXT_CACHE_TAGS_HEADER),!c.cacheControl||e.getHeader("Cache-Control")||_.get("Cache-Control")||_.set("Cache-Control",(0,y.getCacheControlHeader)(c.cacheControl)),await (0,g.sendResponse)(B,W,new Response(c.value.body,{headers:_,status:c.value.status||200})),null};H?await u(H):await U.withPropagatedContext(t.headers,()=>U.trace(_.BaseServerSpan.handleRequest,{spanName:`${P} ${r}`,kind:o.SpanKind.SERVER,attributes:{"http.method":P,"http.target":t.url}},u))}catch(e){if(e instanceof f.NoFallbackError||await x.onRequestError(t,e,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:A})},!1,N),q)throw e;return await (0,g.sendResponse)(B,W,new Response(null,{status:500})),null}}t.s(["handler",()=>b,"patchFetch",()=>w,"routeModule",()=>x,"serverHooks",()=>N,"workAsyncStorage",()=>S,"workUnitAsyncStorage",()=>T]),i()}catch(t){i(t)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__3721c6ae._.js.map