module.exports=[408,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_runs_%5BrunId%5D_route_actions_4507c282.js.map