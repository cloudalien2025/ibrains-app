module.exports=[83813,t=>{"use strict";function e(t,e,i){return Math.max(e,Math.min(i,t))}function i(t,e){let i=`${t} ${e.join(" ")}`.toLowerCase();return/(hotel|restaurant|travel|tour|hospitality|resort)/.test(i)?"hospitality-travel":/(medical|dental|clinic|health)/.test(i)?"health-medical":/(law|legal|attorney|finance|accounting|tax)/.test(i)?"legal-financial":/(school|education|training|academy)/.test(i)?"education":/(home|plumb|electric|roof|contractor|service)/.test(i)?"home-services":"general"}function r(t){let i=t.riskTierOverride??"medium",r=e(60+3*t.schemaSignals.length+t.taxonomySignals.length,0,100),s=e(60+10*!!t.description+5*!!t.ctaText,0,100),a=e(50+5*t.credentialsSignals.length+4*t.evidenceSignals.length+Math.round((t.averageRating??0)*4)+Math.min(10,t.reviewCount/10),0,100),o=e(50+10*t.authorityPosts.filter(t=>"published"===t.status).length+5*t.authorityPosts.filter(t=>t.blogToListingLinked&&t.listingToBlogLinked).length,0,100),n=e(55+8*!!t.contact+8*!!t.ctaText,0,100),l="high"===i?90:100,u="high"===i?92:100,_=Math.min(o,l),c=Math.min(a,u),d=Math.round((r+s+c+_+n)/5);return{listingId:t.listingId,vertical:t.vertical,riskTier:i,totalScore:d,scores:{structure:r,clarity:s,trust:c,authority:_,actionability:n},caps:{authorityCap:l,trustCap:u}}}function s(t){if(0===t.length)return{readiness:0,pillars:{structure:0,clarity:0,trust:0,authority:0,actionability:0}};let e=t.reduce((t,e)=>(t.structure+=e.scores.structure,t.clarity+=e.scores.clarity,t.trust+=e.scores.trust,t.authority+=e.scores.authority,t.actionability+=e.scores.actionability,t.total+=e.totalScore,t),{structure:0,clarity:0,trust:0,authority:0,actionability:0,total:0}),i=t.length;return{readiness:Math.round(e.total/i),pillars:{structure:Math.round(e.structure/i),clarity:Math.round(e.clarity/i),trust:Math.round(e.trust/i),authority:Math.round(e.authority/i),actionability:Math.round(e.actionability/i)}}}t.s(["computeSiteReadiness",()=>s,"detectVerticalFromSignals",()=>i,"evaluateListingSelection",()=>r])},28239,t=>t.a(async(e,i)=>{try{var r=t.i(18669),s=t.i(28248);t.i(54799);var a=t.i(83813),o=e([r,s]);function n(t,e,i){return Math.min(i,Math.max(e,t))}function l(t){return"string"==typeof t?t:""}function u(t){return Array.isArray(t)?t.filter(t=>"string"==typeof t):[]}function _(t,e,i){let r=t.raw_json??{},s=t.title??l(r.title)??t.source_id,o=l(r.group_desc)||l(r.short_description)||l(r.description)||l(r.content)||l(r.content?.rendered)||l(r.excerpt),_=l(r.group_category)||l(r.category)||l(r.category_name)||l(r.primary_category?.name),c=l(r.post_location)||l(r.location)||l(r.city)||l(r.address)||l(r.service_area),d=l(r.phone)||l(r.phone1)||l(r.email)||l(r.contact)||l(r.website),g=l(r.cta)||l(r.call_to_action)||l(r.booking_url)||l(r.contact_url),p=[...u(r.schema_types)??[],...r.structured_data?["structured_data"]:[],...r.schema_mapping?["schema_mapping"]:[]],y=[_,...u(r.tags),...u(r.categories),...u(r.taxonomy_terms)].filter(Boolean),m=[l(r.license),l(r.certification),l(r.accreditation)].filter(Boolean),h=[l(r.case_studies),l(r.testimonials),l(r.portfolio),l(r.years_in_business)].filter(Boolean),f=[l(r.business_name),l(r.nap_name),l(r.nap_phone),l(r.nap_address)].filter(Boolean),b=Number(r.review_count??r.reviews_count??0)||0,E=r.average_rating??r.rating??null,v=(0,a.detectVerticalFromSignals)(_,y),k=i.verticalOverride??v,S=i.riskTierOverrides[k]??null,T=e.map(t=>{var e;let i=(t.metadata_json??{}).quality_score,r="number"==typeof i?n(i,0,100):"published"===t.status?78:55*("draft"===t.status);return{slot:t.slot_index,type:(e=t.post_type,"comparison"===e||"best_of"===e||"contextual_guide"===e||"persona_intent"===e?e:"contextual_guide"),status:t.status,focusTopic:t.focus_topic,title:t.title??"",qualityScore:r,blogToListingLinked:"linked"===t.blog_to_listing_link_status,listingToBlogLinked:"linked"===t.listing_to_blog_link_status}}),$=Number(r.cluster_density??.3),N=Number(r.orphan_risk??.5);return{listingId:t.source_id,title:s,description:o,category:_,location:c,contact:d,ctaText:g,schemaSignals:p,taxonomySignals:y,credentialsSignals:m,reviewCount:b,averageRating:"number"==typeof E?E:null,evidenceSignals:h,identitySignals:f,internalMentionsCount:Number(r.internal_mentions_count??0),clusterDensity:Number.isFinite($)?n($,0,1):.3,orphanRisk:Number.isFinite(N)?n(N,0,1):.5,vertical:k,riskTierOverride:S,authorityPosts:T}}async function c(t){let e=(await (0,r.query)(`
    SELECT vertical_override, risk_tier_overrides_json, image_style_preference, updated_at
    FROM directoryiq_settings
    WHERE user_id = $1
    LIMIT 1
    `,[t]))[0];if(!e)return{verticalOverride:null,riskTierOverrides:{},imageStylePreference:"editorial clean",updatedAt:null};let i={},s=e.risk_tier_overrides_json??{};for(let[t,e]of Object.entries(s))("home-services"===t||"health-medical"===t||"legal-financial"===t||"hospitality-travel"===t||"education"===t||"general"===t)&&("low"===e||"medium"===e||"high"===e)&&(i[t]=e);let a=e.vertical_override;return{verticalOverride:"home-services"===a||"health-medical"===a||"legal-financial"===a||"hospitality-travel"===a||"education"===a||"general"===a?a:null,riskTierOverrides:i,imageStylePreference:e.image_style_preference?.trim()||"editorial clean",updatedAt:e.updated_at}}async function d(t,e){let i=["comparison","best_of","contextual_guide","persona_intent"];for(let s=0;s<4;s+=1){let a=s+1;await (0,r.query)(`
      INSERT INTO directoryiq_authority_posts
      (user_id, listing_source_id, slot_index, post_type, focus_topic, status)
      VALUES ($1, $2, $3, $4, $5, 'not_created')
      ON CONFLICT (user_id, listing_source_id, slot_index)
      DO NOTHING
      `,[t,e,a,i[s],""])}}async function g(t,e){return await d(t,e),await (0,r.query)(`
    SELECT
      id,
      listing_source_id,
      slot_index,
      post_type,
      focus_topic,
      title,
      status,
      draft_markdown,
      draft_html,
      featured_image_prompt,
      featured_image_url,
      published_post_id,
      published_url,
      blog_to_listing_link_status,
      listing_to_blog_link_status,
      metadata_json,
      updated_at
    FROM directoryiq_authority_posts
    WHERE user_id = $1 AND listing_source_id = $2
    ORDER BY slot_index ASC
    `,[t,e])}async function p(t,e,i){return await d(t,e),(await (0,r.query)(`
    SELECT
      id,
      listing_source_id,
      slot_index,
      post_type,
      focus_topic,
      title,
      status,
      draft_markdown,
      draft_html,
      featured_image_prompt,
      featured_image_url,
      published_post_id,
      published_url,
      blog_to_listing_link_status,
      listing_to_blog_link_status,
      metadata_json,
      updated_at
    FROM directoryiq_authority_posts
    WHERE user_id = $1 AND listing_source_id = $2 AND slot_index = $3
    LIMIT 1
    `,[t,e,i]))[0]??null}async function y(t){let e=await c(t),i=await (0,r.query)(`
    SELECT source_id, title, url, updated_at, raw_json
    FROM directoryiq_nodes
    WHERE user_id = $1 AND source_type = 'listing'
    ORDER BY updated_at DESC
    `,[t]),s=i.map(t=>t.source_id),o=[];s.length>0&&(o=await (0,r.query)(`
      SELECT
        id,
        listing_source_id,
        slot_index,
        post_type,
        focus_topic,
        title,
        status,
        draft_markdown,
        draft_html,
        featured_image_prompt,
        featured_image_url,
        published_post_id,
        published_url,
        blog_to_listing_link_status,
        listing_to_blog_link_status,
        metadata_json,
        updated_at
      FROM directoryiq_authority_posts
      WHERE user_id = $1 AND listing_source_id = ANY($2::text[])
      ORDER BY listing_source_id, slot_index ASC
      `,[t,s]));let n=new Map;for(let t of o){let e=n.get(t.listing_source_id)??[];e.push(t),n.set(t.listing_source_id,e)}let l=[],u=[];for(let t of i){let i=n.get(t.source_id)??[],r=_(t,i,e),s=(0,a.evaluateListingSelection)(r);l.push(s),u.push({listingId:t.source_id,name:t.title??t.source_id,url:t.url,authorityStatus:s.scores.authority>=70?"Strong":"Needs Support",trustStatus:s.scores.trust>=70?"Strong":"Needs Trust",lastOptimized:i.some(t=>"published"===t.status)?t.updated_at:null,evaluation:s})}let d=(0,a.computeSiteReadiness)(l),g=e.verticalOverride??u[0]?.evaluation.vertical??"general";return{cards:u,readiness:d.readiness,pillarAverages:d.pillars,verticalDetected:g}}async function m(t,e){let i=await c(t),s=(await (0,r.query)(`
    SELECT source_id, title, url, updated_at, raw_json
    FROM directoryiq_nodes
    WHERE user_id = $1 AND source_type = 'listing' AND source_id = $2
    LIMIT 1
    `,[t,e]))[0]??null;if(!s)return{listing:null,authorityPosts:[],evaluation:null,settings:i};let o=await g(t,s.source_id),n=_(s,o,i),l=(0,a.evaluateListingSelection)(n);return{listing:s,authorityPosts:o,evaluation:l,settings:i}}async function h(t,e,i,s){await (0,r.query)(`
    INSERT INTO directoryiq_authority_posts
    (user_id, listing_source_id, slot_index, post_type, focus_topic, title, status, draft_markdown, draft_html, blog_to_listing_link_status, metadata_json, updated_at)
    VALUES ($1, $2, $3, $4, $5, $6, 'draft', $7, $8, $9, $10::jsonb, now())
    ON CONFLICT (user_id, listing_source_id, slot_index)
    DO UPDATE SET
      post_type = EXCLUDED.post_type,
      focus_topic = EXCLUDED.focus_topic,
      title = EXCLUDED.title,
      status = 'draft',
      draft_markdown = EXCLUDED.draft_markdown,
      draft_html = EXCLUDED.draft_html,
      blog_to_listing_link_status = EXCLUDED.blog_to_listing_link_status,
      metadata_json = EXCLUDED.metadata_json,
      updated_at = now()
    `,[t,e,i,s.type,s.focusTopic,s.title,s.draftMarkdown,s.draftHtml,s.blogToListingStatus,JSON.stringify(s.metadata)])}async function f(t,e,i,s){await (0,r.query)(`
    UPDATE directoryiq_authority_posts
    SET
      featured_image_prompt = $4,
      featured_image_url = $5,
      updated_at = now()
    WHERE user_id = $1 AND listing_source_id = $2 AND slot_index = $3
    `,[t,e,i,s.imagePrompt,s.imageUrl])}async function b(t,e,i,s){await (0,r.query)(`
    UPDATE directoryiq_authority_posts
    SET
      status = 'published',
      published_post_id = $4,
      published_url = $5,
      blog_to_listing_link_status = $6,
      listing_to_blog_link_status = $7,
      metadata_json = $8::jsonb,
      updated_at = now()
    WHERE user_id = $1 AND listing_source_id = $2 AND slot_index = $3
    `,[t,e,i,s.publishedPostId,s.publishedUrl,s.blogToListingStatus,s.listingToBlogStatus,JSON.stringify(s.metadata)])}async function E(t,e){return(await (0,r.query)(`
    INSERT INTO directoryiq_versions
    (user_id, listing_source_id, authority_post_id, action_type, version_label, score_snapshot_json, content_delta_json, link_delta_json)
    VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8::jsonb)
    RETURNING id
    `,[t,e.listingId,e.authorityPostId??null,e.actionType,e.versionLabel,JSON.stringify(e.scoreSnapshot),JSON.stringify(e.contentDelta),JSON.stringify(e.linkDelta)]))[0].id}[r,s]=o.then?(await o)():o,t.s(["addDirectoryIqVersion",()=>E,"getAllListingsWithEvaluations",()=>y,"getAuthorityPostBySlot",()=>p,"getDirectoryIqSettings",()=>c,"getListingEvaluation",()=>m,"markPostPublished",()=>b,"saveAuthorityImage",()=>f,"upsertAuthorityPostDraft",()=>h]),i()}catch(t){i(t)}},!1),51500,t=>{"use strict";let e=process.env.DIRECTORYIQ_APPROVAL_TOKEN_SECRET??"directoryiq-dev-secret";function i(t){let e=Number.parseInt(t,10);return!Number.isFinite(e)||e<1?1:e}function r(t){let e=t.trim().toLowerCase();return"comparison"===e||"best_of"===e||"contextual_guide"===e||"persona_intent"===e?e:"contextual_guide"}function s(t){let e=t.trim()||"VERSION",i=new Date().toISOString().replace(/[-:]/g,"").replace(/\..+$/,"");return`${e}-${i}`}function a(t){let i=JSON.stringify({...t,secret:e});return Buffer.from(i,"utf8").toString("base64url")}function o(t,i){if(!t)return{ok:!1,reason:"Missing approval token."};try{let r=Buffer.from(t,"base64url").toString("utf8"),s=JSON.parse(r);if(s.secret!==e)return{ok:!1,reason:"Token signature mismatch."};if(s.userId!==i.userId)return{ok:!1,reason:"Token user mismatch."};if(s.listingId!==i.listingId)return{ok:!1,reason:"Token listing mismatch."};if(s.action!==i.action)return{ok:!1,reason:"Token action mismatch."};if((i.slot??null)!==(s.slot??null))return{ok:!1,reason:"Token slot mismatch."};return{ok:!0,reason:"ok"}}catch{return{ok:!1,reason:"Malformed approval token."}}}t.s(["issueApprovalToken",()=>a,"makeVersionLabel",()=>s,"normalizePostType",()=>r,"normalizeSlot",()=>i,"verifyApprovalToken",()=>o])}];

//# sourceMappingURL=_27d38ea4._.js.map