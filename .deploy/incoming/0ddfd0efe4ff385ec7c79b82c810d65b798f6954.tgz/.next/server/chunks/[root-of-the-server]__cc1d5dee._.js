module.exports=[18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},23862,e=>e.a(async(t,r)=>{try{let t=await e.y("pg-587764f78a6c7a9c");e.n(t),r()}catch(e){r(e)}},!0),18669,e=>e.a(async(t,r)=>{try{var i=e.i(23862),s=t([i]);[i]=s.then?(await s)():s;let E=null,o=!1,d=null;function a(){if(!E){let e=process.env.DATABASE_URL;if(!e)throw Error("DATABASE_URL not configured");E=new i.Pool({connectionString:e})}return E}async function T(){o||(d||(d=(async()=>{let e=a();await e.query(`
        CREATE EXTENSION IF NOT EXISTS pgcrypto;

        CREATE TABLE IF NOT EXISTS users (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          external_id TEXT UNIQUE,
          email TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE TABLE IF NOT EXISTS integrations (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          provider TEXT NOT NULL,
          shop_domain TEXT NOT NULL,
          access_token_ciphertext TEXT NOT NULL,
          scopes TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'connected',
          installed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          last_verified_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, provider, shop_domain)
        );

        CREATE TABLE IF NOT EXISTS oauth_states (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          provider TEXT NOT NULL,
          shop_domain TEXT NOT NULL,
          state TEXT NOT NULL UNIQUE,
          expires_at TIMESTAMPTZ NOT NULL,
          used_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE TABLE IF NOT EXISTS ingest_runs (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
          status TEXT NOT NULL,
          started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          finished_at TIMESTAMPTZ,
          products_count INTEGER NOT NULL DEFAULT 0,
          articles_count INTEGER NOT NULL DEFAULT 0,
          pages_count INTEGER NOT NULL DEFAULT 0,
          collections_count INTEGER NOT NULL DEFAULT 0,
          error_message TEXT
        );

        CREATE TABLE IF NOT EXISTS site_nodes (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
          node_type TEXT NOT NULL,
          source_id TEXT NOT NULL,
          handle TEXT,
          title TEXT NOT NULL,
          url TEXT,
          tags JSONB NOT NULL DEFAULT '[]',
          body_text TEXT,
          body_html TEXT,
          image_url TEXT,
          published_at TIMESTAMPTZ,
          updated_at_source TIMESTAMPTZ,
          raw_json JSONB NOT NULL DEFAULT '{}',
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (integration_id, source_id)
        );

        CREATE INDEX IF NOT EXISTS idx_site_nodes_integration_type
          ON site_nodes(integration_id, node_type);

        CREATE TABLE IF NOT EXISTS product_blog_links (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
          product_node_id UUID NOT NULL REFERENCES site_nodes(id) ON DELETE CASCADE,
          article_node_id UUID NOT NULL REFERENCES site_nodes(id) ON DELETE CASCADE,
          score NUMERIC NOT NULL,
          reason TEXT NOT NULL,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (product_node_id, article_node_id)
        );

        CREATE TABLE IF NOT EXISTS byo_api_keys (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          provider TEXT NOT NULL,
          key_ciphertext TEXT NOT NULL,
          key_last4 TEXT,
          key_length INTEGER,
          label TEXT,
          last_verified_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, provider)
        );

        ALTER TABLE byo_api_keys
          ADD COLUMN IF NOT EXISTS key_last4 TEXT;

        ALTER TABLE byo_api_keys
          ADD COLUMN IF NOT EXISTS key_length INTEGER;

        ALTER TABLE byo_api_keys
          ADD COLUMN IF NOT EXISTS last_verified_at TIMESTAMPTZ;

        CREATE TABLE IF NOT EXISTS directoryiq_signal_source_credentials (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          connector_id TEXT NOT NULL,
          secret_ciphertext TEXT NOT NULL,
          secret_last4 TEXT,
          secret_length INTEGER,
          label TEXT,
          config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          last_verified_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, connector_id)
        );

        CREATE TABLE IF NOT EXISTS integrations_credentials (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          product TEXT NOT NULL,
          provider TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'connected',
          secret_ciphertext TEXT,
          secret_iv TEXT,
          secret_tag TEXT,
          secret_last4 TEXT,
          meta_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          saved_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, product, provider)
        );

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'connected';

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_ciphertext TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_iv TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_tag TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS secret_last4 TEXT;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS meta_json JSONB NOT NULL DEFAULT '{}'::jsonb;

        ALTER TABLE integrations_credentials
          ADD COLUMN IF NOT EXISTS saved_at TIMESTAMPTZ NOT NULL DEFAULT now();

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS secret_last4 TEXT;

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS secret_length INTEGER;

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS last_verified_at TIMESTAMPTZ;

        ALTER TABLE directoryiq_signal_source_credentials
          ADD COLUMN IF NOT EXISTS config_json JSONB NOT NULL DEFAULT '{}'::jsonb;

        CREATE TABLE IF NOT EXISTS directoryiq_ingest_runs (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          status TEXT NOT NULL,
          source_base_url TEXT,
          started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          finished_at TIMESTAMPTZ,
          listings_count INTEGER NOT NULL DEFAULT 0,
          blog_posts_count INTEGER NOT NULL DEFAULT 0,
          error_message TEXT
        );

        CREATE TABLE IF NOT EXISTS directoryiq_nodes (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          source_type TEXT NOT NULL,
          source_id TEXT NOT NULL,
          title TEXT,
          url TEXT,
          updated_at_source TIMESTAMPTZ,
          raw_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, source_type, source_id)
        );

        CREATE TABLE IF NOT EXISTS directoryiq_settings (
          user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
          vertical_override TEXT,
          risk_tier_overrides_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          image_style_preference TEXT NOT NULL DEFAULT 'editorial clean',
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE TABLE IF NOT EXISTS directoryiq_authority_posts (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          listing_source_id TEXT NOT NULL,
          slot_index INTEGER NOT NULL CHECK (slot_index >= 1 AND slot_index <= 4),
          post_type TEXT NOT NULL,
          focus_topic TEXT NOT NULL DEFAULT '',
          title TEXT,
          status TEXT NOT NULL DEFAULT 'not_created',
          draft_markdown TEXT,
          draft_html TEXT,
          featured_image_prompt TEXT,
          featured_image_url TEXT,
          published_post_id TEXT,
          published_url TEXT,
          blog_to_listing_link_status TEXT NOT NULL DEFAULT 'missing',
          listing_to_blog_link_status TEXT NOT NULL DEFAULT 'missing',
          metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, listing_source_id, slot_index)
        );

        CREATE INDEX IF NOT EXISTS idx_directoryiq_authority_posts_listing
          ON directoryiq_authority_posts(user_id, listing_source_id);

        CREATE TABLE IF NOT EXISTS directoryiq_versions (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          listing_source_id TEXT NOT NULL,
          authority_post_id UUID REFERENCES directoryiq_authority_posts(id) ON DELETE SET NULL,
          action_type TEXT NOT NULL,
          version_label TEXT NOT NULL,
          score_snapshot_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          content_delta_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          link_delta_json JSONB NOT NULL DEFAULT '{}'::jsonb,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );

        CREATE INDEX IF NOT EXISTS idx_directoryiq_versions_user_created
          ON directoryiq_versions(user_id, created_at DESC);

        CREATE TABLE IF NOT EXISTS directoryiq_listing_upgrades (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          listing_source_id TEXT NOT NULL,
          created_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          original_description_hash TEXT NOT NULL,
          original_description TEXT NOT NULL DEFAULT '',
          proposed_description TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'draft',
          bd_update_ref TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          previewed_at TIMESTAMPTZ,
          pushed_at TIMESTAMPTZ
        );

        CREATE INDEX IF NOT EXISTS idx_directoryiq_listing_upgrades_listing
          ON directoryiq_listing_upgrades(user_id, listing_source_id, created_at DESC);

        CREATE TABLE IF NOT EXISTS brain_snapshots (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          brain_id TEXT NOT NULL,
          snapshot_json JSONB NOT NULL DEFAULT '[]'::jsonb,
          snapshot_status TEXT NOT NULL DEFAULT 'needs_connection',
          snapshot_updated_at TIMESTAMPTZ,
          hints_json JSONB NOT NULL DEFAULT '[]'::jsonb,
          last_error TEXT,
          created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          UNIQUE (user_id, brain_id)
        );

        CREATE TABLE IF NOT EXISTS snapshot_refresh_locks (
          user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          brain_id TEXT NOT NULL,
          locked_until TIMESTAMPTZ NOT NULL,
          updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
          PRIMARY KEY (user_id, brain_id)
        );
      `),o=!0})().catch(e=>{throw d=null,e})),await d)}async function n(e,t=[]){return await T(),(await a().query(e,t)).rows}e.s(["query",()=>n]),r()}catch(e){r(e)}},!1),23203,e=>e.a(async(t,r)=>{try{var i=e.i(54799),s=e.i(18669),a=t([s]);[s]=a.then?(await a)():a;let o="00000000-0000-4000-8000-000000000001";function T(e){if(!e)return null;let t=e.trim().toLowerCase();return/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(t)?t:null}function n(e){if(!e)return o;let t=T(e.headers.get("x-user-id"));if(t)return t;let r=T(e.nextUrl.searchParams.get("user_id"));if(r)return r;let s=e.headers.get("x-user-id")??e.headers.get("x-user-email")??e.headers.get("x-forwarded-email")??e.headers.get("cf-access-authenticated-user-email");if(s&&s.trim().length>0){let e,t,r;return e=i.default.createHash("sha256").update(s.trim().toLowerCase()).digest(),(t=Buffer.from(e.subarray(0,16)))[6]=15&t[6]|64,t[8]=63&t[8]|128,r=t.toString("hex"),`${r.slice(0,8)}-${r.slice(8,12)}-${r.slice(12,16)}-${r.slice(16,20)}-${r.slice(20,32)}`}return o}async function E(e){await (0,s.query)(`
    INSERT INTO users (id, external_id, email)
    VALUES ($1, $2, $3)
    ON CONFLICT (id) DO NOTHING
    `,[e,`local:${e}`,null])}e.s(["ensureUser",()=>E,"resolveUserId",()=>n]),r()}catch(e){r(e)}},!1),39719,e=>{"use strict";var t=e.i(54799);function r(){let e=process.env.INTEGRATIONS_ENCRYPTION_KEY??process.env.SERVER_ENCRYPTION_KEY;if(!e)throw Error("INTEGRATIONS_ENCRYPTION_KEY not configured");let t=e.trim();if(/^[0-9a-fA-F]{64}$/.test(t))return Buffer.from(t,"hex");let r=Buffer.from(t,"base64");if(32!==r.length)throw Error("INTEGRATIONS_ENCRYPTION_KEY must be 32 bytes (base64 or hex)");return r}function i(e,i){let s=r(),a=t.default.randomBytes(12),T=t.default.createCipheriv("aes-256-gcm",s,a);i&&T.setAAD(Buffer.from(i,"utf8"));let n=Buffer.concat([T.update(e,"utf8"),T.final()]),E=T.getAuthTag(),o={iv:a.toString("base64"),tag:E.toString("base64"),ciphertext:n.toString("base64")};return Buffer.from(JSON.stringify(o),"utf8").toString("base64")}function s(e,i){let s=r(),a=JSON.parse(Buffer.from(e,"base64").toString("utf8")),T=t.default.createDecipheriv("aes-256-gcm",s,Buffer.from(a.iv,"base64"));return i&&T.setAAD(Buffer.from(i,"utf8")),T.setAuthTag(Buffer.from(a.tag,"base64")),Buffer.concat([T.update(Buffer.from(a.ciphertext,"base64")),T.final()]).toString("utf8")}e.s(["decryptSecret",()=>s,"encryptSecret",()=>i])},30114,e=>{"use strict";let t=["openai","ga4","serpapi"];function r(e){return t.includes(e)}function i(e){let r=new Map(e.map(e=>[e.provider,e]));return t.reduce((e,t)=>{let i=r.get(t);return e[t]={provider:t,label:i?.label??null,connected:!!i,masked_key:i?function(e,t){if(!t||t<=0)return"Saved";let r=Math.max(0,t-4),i="*".repeat(Math.min(r,12));return e?`${i}${e}`:i||"Saved"}(i.key_last4??null,i.key_length??null):"",updated_at:i?.updated_at??null},e},{})}function s(e){let t=e.apiKey.trim(),r=t.slice(-4);return{provider:e.provider,keyLast4:r,keyLength:t.length,label:e.label?.trim()||null}}e.s(["buildByoSavePayload",()=>s,"isByoProvider",()=>r,"toByoStatusMap",()=>i])},26899,e=>e.a(async(t,r)=>{try{var i=e.i(89171),s=e.i(39719),a=e.i(18669),T=e.i(23203),n=e.i(30114),E=t([a,T]);async function o(e){try{let t=(0,T.resolveUserId)(e);await (0,T.ensureUser)(t);let r=await (0,a.query)(`
      SELECT id, provider, key_last4, key_length, label, updated_at
      FROM byo_api_keys
      WHERE user_id = $1
      ORDER BY provider ASC
      `,[t]),s=Object.values((0,n.toByoStatusMap)(r));return i.NextResponse.json({providers:s})}catch(t){let e=t instanceof Error?t.message:"Unknown BYO keys error";return i.NextResponse.json({error:e},{status:500})}}async function d(e){try{let t=(0,T.resolveUserId)(e);await (0,T.ensureUser)(t);let r=await e.json(),E=(r.provider??"").toLowerCase().trim(),o=(r.api_key??"").trim();if(!(0,n.isByoProvider)(E))return i.NextResponse.json({error:"provider must be openai|ga4|serpapi"},{status:400});if(!o)return i.NextResponse.json({error:"api_key is required"},{status:400});let d=(0,n.buildByoSavePayload)({provider:E,apiKey:o,label:r.label}),N=(0,s.encryptSecret)(o,`${t}:byo:${E}`);return await (0,a.query)(`
      INSERT INTO byo_api_keys (user_id, provider, key_ciphertext, key_last4, key_length, label, last_verified_at)
      VALUES ($1, $2, $3, $4, $5, $6, now())
      ON CONFLICT (user_id, provider)
      DO UPDATE SET
        key_ciphertext = EXCLUDED.key_ciphertext,
        key_last4 = EXCLUDED.key_last4,
        key_length = EXCLUDED.key_length,
        label = EXCLUDED.label,
        last_verified_at = now(),
        updated_at = now()
      `,[t,E,N,d.keyLast4,d.keyLength,d.label]),i.NextResponse.json({ok:!0,provider:E,connected:!0})}catch(t){let e=t instanceof Error?t.message:"Unknown BYO key save error";return i.NextResponse.json({error:e},{status:500})}}async function N(e){try{let t=(0,T.resolveUserId)(e);await (0,T.ensureUser)(t);let r=(e.nextUrl.searchParams.get("provider")??"").toLowerCase().trim();if(!(0,n.isByoProvider)(r))return i.NextResponse.json({error:"provider must be openai|ga4|serpapi"},{status:400});return await (0,a.query)("DELETE FROM byo_api_keys WHERE user_id = $1 AND provider = $2",[t,r]),i.NextResponse.json({ok:!0})}catch(t){let e=t instanceof Error?t.message:"Unknown BYO key delete error";return i.NextResponse.json({error:e},{status:500})}}[a,T]=E.then?(await E)():E,e.s(["DELETE",()=>N,"GET",()=>o,"POST",()=>d,"runtime",0,"nodejs"]),r()}catch(e){r(e)}},!1),9336,e=>e.a(async(t,r)=>{try{var i=e.i(47909),s=e.i(74017),a=e.i(96250),T=e.i(59756),n=e.i(61916),E=e.i(74677),o=e.i(69741),d=e.i(16795),N=e.i(87718),u=e.i(95169),L=e.i(47587),l=e.i(66012),_=e.i(70101),c=e.i(26937),U=e.i(10372),A=e.i(93695);e.i(52474);var p=e.i(220),O=e.i(26899),I=t([O]);[O]=I.then?(await I)():I;let R=new i.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/ecomviper/byo-keys/route",pathname:"/api/ecomviper/byo-keys",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/ecomviper/byo-keys/route.ts",nextConfigOutput:"",userland:O}),{workAsyncStorage:g,workUnitAsyncStorage:y,serverHooks:C}=R;function S(){return(0,a.patchFetch)({workAsyncStorage:g,workUnitAsyncStorage:y})}async function D(e,t,r){R.isDev&&(0,T.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let i="/api/ecomviper/byo-keys/route";i=i.replace(/\/index$/,"")||"/";let a=await R.prepare(e,t,{srcPage:i,multiZoneDraftMode:!1});if(!a)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:O,params:I,nextConfig:S,parsedUrl:D,isDraftMode:g,prerenderManifest:y,routerServerContext:C,isOnDemandRevalidate:f,revalidateOnlyGenerated:h,resolvedPathname:F,clientReferenceManifest:M,serverActionsManifest:X}=a,m=(0,o.normalizeAppPath)(i),v=!!(y.dynamicRoutes[m]||y.routes[F]),x=async()=>((null==C?void 0:C.render404)?await C.render404(e,t,D,!1):t.end("This page could not be found"),null);if(v&&!g){let e=!!y.routes[F],t=y.dynamicRoutes[m];if(t&&!1===t.fallback&&!e){if(S.experimental.adapterPath)return await x();throw new A.NoFallbackError}}let w=null;!v||R.isDev||g||(w=F,w="/index"===w?"/":w);let b=!0===R.isDev||!v,P=v&&!b;X&&M&&(0,E.setManifestsSingleton)({page:i,clientReferenceManifest:M,serverActionsManifest:X});let B=e.method||"GET",k=(0,n.getTracer)(),j=k.getActiveScopeSpan(),q={params:I,prerenderManifest:y,renderOpts:{experimental:{authInterrupts:!!S.experimental.authInterrupts},cacheComponents:!!S.cacheComponents,supportsDynamicResponse:b,incrementalCache:(0,T.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:S.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,i,s)=>R.onRequestError(e,t,i,s,C)},sharedContext:{buildId:O}},Y=new d.NodeNextRequest(e),Z=new d.NodeNextResponse(t),$=N.NextRequestAdapter.fromNodeNextRequest(Y,(0,N.signalFromNodeResponse)(t));try{let a=async e=>R.handle($,q).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=k.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=r.get("next.route");if(s){let t=`${B} ${s}`;e.setAttributes({"next.route":s,"http.route":s,"next.span_name":t}),e.updateName(t)}else e.updateName(`${B} ${i}`)}),E=!!(0,T.getRequestMeta)(e,"minimalMode"),o=async T=>{var n,o;let d=async({previousCacheEntry:s})=>{try{if(!E&&f&&h&&!s)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let i=await a(T);e.fetchMetrics=q.renderOpts.fetchMetrics;let n=q.renderOpts.pendingWaitUntil;n&&r.waitUntil&&(r.waitUntil(n),n=void 0);let o=q.renderOpts.collectedTags;if(!v)return await (0,l.sendResponse)(Y,Z,i,q.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),t=(0,_.toNodeOutgoingHttpHeaders)(i.headers);o&&(t[U.NEXT_CACHE_TAGS_HEADER]=o),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==q.renderOpts.collectedRevalidate&&!(q.renderOpts.collectedRevalidate>=U.INFINITE_CACHE)&&q.renderOpts.collectedRevalidate,s=void 0===q.renderOpts.collectedExpire||q.renderOpts.collectedExpire>=U.INFINITE_CACHE?void 0:q.renderOpts.collectedExpire;return{value:{kind:p.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:s}}}}catch(t){throw(null==s?void 0:s.isStale)&&await R.onRequestError(e,t,{routerKind:"App Router",routePath:i,routeType:"route",revalidateReason:(0,L.getRevalidateReason)({isStaticGeneration:P,isOnDemandRevalidate:f})},!1,C),t}},N=await R.handleResponse({req:e,nextConfig:S,cacheKey:w,routeKind:s.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:f,revalidateOnlyGenerated:h,responseGenerator:d,waitUntil:r.waitUntil,isMinimalMode:E});if(!v)return null;if((null==N||null==(n=N.value)?void 0:n.kind)!==p.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==N||null==(o=N.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});E||t.setHeader("x-nextjs-cache",f?"REVALIDATED":N.isMiss?"MISS":N.isStale?"STALE":"HIT"),g&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,_.fromNodeOutgoingHttpHeaders)(N.value.headers);return E&&v||u.delete(U.NEXT_CACHE_TAGS_HEADER),!N.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,c.getCacheControlHeader)(N.cacheControl)),await (0,l.sendResponse)(Y,Z,new Response(N.value.body,{headers:u,status:N.value.status||200})),null};j?await o(j):await k.withPropagatedContext(e.headers,()=>k.trace(u.BaseServerSpan.handleRequest,{spanName:`${B} ${i}`,kind:n.SpanKind.SERVER,attributes:{"http.method":B,"http.target":e.url}},o))}catch(t){if(t instanceof A.NoFallbackError||await R.onRequestError(e,t,{routerKind:"App Router",routePath:m,routeType:"route",revalidateReason:(0,L.getRevalidateReason)({isStaticGeneration:P,isOnDemandRevalidate:f})},!1,C),v)throw t;return await (0,l.sendResponse)(Y,Z,new Response(null,{status:500})),null}}e.s(["handler",()=>D,"patchFetch",()=>S,"routeModule",()=>R,"serverHooks",()=>C,"workAsyncStorage",()=>g,"workUnitAsyncStorage",()=>y]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__cc1d5dee._.js.map