module.exports=[18622,(t,e,i)=>{e.exports=t.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(t,e,i)=>{e.exports=t.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(t,e,i)=>{e.exports=t.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(t,e,i)=>{e.exports=t.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},83813,t=>{"use strict";function e(t,e,i){return Math.max(e,Math.min(i,t))}function i(t,e){let i=`${t} ${e.join(" ")}`.toLowerCase();return/(hotel|restaurant|travel|tour|hospitality|resort)/.test(i)?"hospitality-travel":/(medical|dental|clinic|health)/.test(i)?"health-medical":/(law|legal|attorney|finance|accounting|tax)/.test(i)?"legal-financial":/(school|education|training|academy)/.test(i)?"education":/(home|plumb|electric|roof|contractor|service)/.test(i)?"home-services":"general"}function r(t){let i=t.riskTierOverride??"medium",r=e(60+3*t.schemaSignals.length+t.taxonomySignals.length,0,100),a=e(60+10*!!t.description+5*!!t.ctaText,0,100),n=e(50+5*t.credentialsSignals.length+4*t.evidenceSignals.length+Math.round((t.averageRating??0)*4)+Math.min(10,t.reviewCount/10),0,100),s=e(50+10*t.authorityPosts.filter(t=>"published"===t.status).length+5*t.authorityPosts.filter(t=>t.blogToListingLinked&&t.listingToBlogLinked).length,0,100),o=e(55+8*!!t.contact+8*!!t.ctaText,0,100),l="high"===i?90:100,u="high"===i?92:100,d=Math.min(s,l),c=Math.min(n,u),_=Math.round((r+a+c+d+o)/5);return{listingId:t.listingId,vertical:t.vertical,riskTier:i,totalScore:_,scores:{structure:r,clarity:a,trust:c,authority:d,actionability:o},caps:{authorityCap:l,trustCap:u}}}function a(t){if(0===t.length)return{readiness:0,pillars:{structure:0,clarity:0,trust:0,authority:0,actionability:0}};let e=t.reduce((t,e)=>(t.structure+=e.scores.structure,t.clarity+=e.scores.clarity,t.trust+=e.scores.trust,t.authority+=e.scores.authority,t.actionability+=e.scores.actionability,t.total+=e.totalScore,t),{structure:0,clarity:0,trust:0,authority:0,actionability:0,total:0}),i=t.length;return{readiness:Math.round(e.total/i),pillars:{structure:Math.round(e.structure/i),clarity:Math.round(e.clarity/i),trust:Math.round(e.trust/i),authority:Math.round(e.authority/i),actionability:Math.round(e.actionability/i)}}}t.s(["computeSiteReadiness",()=>a,"detectVerticalFromSignals",()=>i,"evaluateListingSelection",()=>r])},28239,t=>t.a(async(e,i)=>{try{var r=t.i(18669),a=t.i(28248);t.i(54799);var n=t.i(83813),s=e([r,a]);function o(t,e,i){return Math.min(i,Math.max(e,t))}function l(t){return"string"==typeof t?t:""}function u(t){return Array.isArray(t)?t.filter(t=>"string"==typeof t):[]}function d(t,e,i){let r=t.raw_json??{},a=t.title??l(r.title)??t.source_id,s=l(r.group_desc)||l(r.short_description)||l(r.description)||l(r.content)||l(r.content?.rendered)||l(r.excerpt),d=l(r.group_category)||l(r.category)||l(r.category_name)||l(r.primary_category?.name),c=l(r.post_location)||l(r.location)||l(r.city)||l(r.address)||l(r.service_area),_=l(r.phone)||l(r.phone1)||l(r.email)||l(r.contact)||l(r.website),p=l(r.cta)||l(r.call_to_action)||l(r.booking_url)||l(r.contact_url),g=[...u(r.schema_types)??[],...r.structured_data?["structured_data"]:[],...r.schema_mapping?["schema_mapping"]:[]],h=[d,...u(r.tags),...u(r.categories),...u(r.taxonomy_terms)].filter(Boolean),m=[l(r.license),l(r.certification),l(r.accreditation)].filter(Boolean),f=[l(r.case_studies),l(r.testimonials),l(r.portfolio),l(r.years_in_business)].filter(Boolean),y=[l(r.business_name),l(r.nap_name),l(r.nap_phone),l(r.nap_address)].filter(Boolean),v=Number(r.review_count??r.reviews_count??0)||0,E=r.average_rating??r.rating??null,b=(0,n.detectVerticalFromSignals)(d,h),R=i.verticalOverride??b,w=i.riskTierOverrides[R]??null,x=e.map(t=>{var e;let i=(t.metadata_json??{}).quality_score,r="number"==typeof i?o(i,0,100):"published"===t.status?78:55*("draft"===t.status);return{slot:t.slot_index,type:(e=t.post_type,"comparison"===e||"best_of"===e||"contextual_guide"===e||"persona_intent"===e?e:"contextual_guide"),status:t.status,focusTopic:t.focus_topic,title:t.title??"",qualityScore:r,blogToListingLinked:"linked"===t.blog_to_listing_link_status,listingToBlogLinked:"linked"===t.listing_to_blog_link_status}}),S=Number(r.cluster_density??.3),T=Number(r.orphan_risk??.5);return{listingId:t.source_id,title:a,description:s,category:d,location:c,contact:_,ctaText:p,schemaSignals:g,taxonomySignals:h,credentialsSignals:m,reviewCount:v,averageRating:"number"==typeof E?E:null,evidenceSignals:f,identitySignals:y,internalMentionsCount:Number(r.internal_mentions_count??0),clusterDensity:Number.isFinite(S)?o(S,0,1):.3,orphanRisk:Number.isFinite(T)?o(T,0,1):.5,vertical:R,riskTierOverride:w,authorityPosts:x}}async function c(t){let e=(await (0,r.query)(`
    SELECT vertical_override, risk_tier_overrides_json, image_style_preference, updated_at
    FROM directoryiq_settings
    WHERE user_id = $1
    LIMIT 1
    `,[t]))[0];if(!e)return{verticalOverride:null,riskTierOverrides:{},imageStylePreference:"editorial clean",updatedAt:null};let i={},a=e.risk_tier_overrides_json??{};for(let[t,e]of Object.entries(a))("home-services"===t||"health-medical"===t||"legal-financial"===t||"hospitality-travel"===t||"education"===t||"general"===t)&&("low"===e||"medium"===e||"high"===e)&&(i[t]=e);let n=e.vertical_override;return{verticalOverride:"home-services"===n||"health-medical"===n||"legal-financial"===n||"hospitality-travel"===n||"education"===n||"general"===n?n:null,riskTierOverrides:i,imageStylePreference:e.image_style_preference?.trim()||"editorial clean",updatedAt:e.updated_at}}async function _(t,e){let i=["comparison","best_of","contextual_guide","persona_intent"];for(let a=0;a<4;a+=1){let n=a+1;await (0,r.query)(`
      INSERT INTO directoryiq_authority_posts
      (user_id, listing_source_id, slot_index, post_type, focus_topic, status)
      VALUES ($1, $2, $3, $4, $5, 'not_created')
      ON CONFLICT (user_id, listing_source_id, slot_index)
      DO NOTHING
      `,[t,e,n,i[a],""])}}async function p(t,e){return await _(t,e),await (0,r.query)(`
    SELECT
      id,
      listing_source_id,
      slot_index,
      post_type,
      focus_topic,
      title,
      status,
      draft_markdown,
      draft_html,
      featured_image_prompt,
      featured_image_url,
      published_post_id,
      published_url,
      blog_to_listing_link_status,
      listing_to_blog_link_status,
      metadata_json,
      updated_at
    FROM directoryiq_authority_posts
    WHERE user_id = $1 AND listing_source_id = $2
    ORDER BY slot_index ASC
    `,[t,e])}async function g(t,e,i){return await _(t,e),(await (0,r.query)(`
    SELECT
      id,
      listing_source_id,
      slot_index,
      post_type,
      focus_topic,
      title,
      status,
      draft_markdown,
      draft_html,
      featured_image_prompt,
      featured_image_url,
      published_post_id,
      published_url,
      blog_to_listing_link_status,
      listing_to_blog_link_status,
      metadata_json,
      updated_at
    FROM directoryiq_authority_posts
    WHERE user_id = $1 AND listing_source_id = $2 AND slot_index = $3
    LIMIT 1
    `,[t,e,i]))[0]??null}async function h(t){let e=await c(t),i=await (0,r.query)(`
    SELECT source_id, title, url, updated_at, raw_json
    FROM directoryiq_nodes
    WHERE user_id = $1 AND source_type = 'listing'
    ORDER BY updated_at DESC
    `,[t]),a=i.map(t=>t.source_id),s=[];a.length>0&&(s=await (0,r.query)(`
      SELECT
        id,
        listing_source_id,
        slot_index,
        post_type,
        focus_topic,
        title,
        status,
        draft_markdown,
        draft_html,
        featured_image_prompt,
        featured_image_url,
        published_post_id,
        published_url,
        blog_to_listing_link_status,
        listing_to_blog_link_status,
        metadata_json,
        updated_at
      FROM directoryiq_authority_posts
      WHERE user_id = $1 AND listing_source_id = ANY($2::text[])
      ORDER BY listing_source_id, slot_index ASC
      `,[t,a]));let o=new Map;for(let t of s){let e=o.get(t.listing_source_id)??[];e.push(t),o.set(t.listing_source_id,e)}let l=[],u=[];for(let t of i){let i=o.get(t.source_id)??[],r=d(t,i,e),a=(0,n.evaluateListingSelection)(r);l.push(a),u.push({listingId:t.source_id,name:t.title??t.source_id,url:t.url,authorityStatus:a.scores.authority>=70?"Strong":"Needs Support",trustStatus:a.scores.trust>=70?"Strong":"Needs Trust",lastOptimized:i.some(t=>"published"===t.status)?t.updated_at:null,evaluation:a})}let _=(0,n.computeSiteReadiness)(l),p=e.verticalOverride??u[0]?.evaluation.vertical??"general";return{cards:u,readiness:_.readiness,pillarAverages:_.pillars,verticalDetected:p}}async function m(t,e){let i=await c(t),a=(await (0,r.query)(`
    SELECT source_id, title, url, updated_at, raw_json
    FROM directoryiq_nodes
    WHERE user_id = $1 AND source_type = 'listing' AND source_id = $2
    LIMIT 1
    `,[t,e]))[0]??null;if(!a)return{listing:null,authorityPosts:[],evaluation:null,settings:i};let s=await p(t,a.source_id),o=d(a,s,i),l=(0,n.evaluateListingSelection)(o);return{listing:a,authorityPosts:s,evaluation:l,settings:i}}async function f(t,e,i,a){await (0,r.query)(`
    INSERT INTO directoryiq_authority_posts
    (user_id, listing_source_id, slot_index, post_type, focus_topic, title, status, draft_markdown, draft_html, blog_to_listing_link_status, metadata_json, updated_at)
    VALUES ($1, $2, $3, $4, $5, $6, 'draft', $7, $8, $9, $10::jsonb, now())
    ON CONFLICT (user_id, listing_source_id, slot_index)
    DO UPDATE SET
      post_type = EXCLUDED.post_type,
      focus_topic = EXCLUDED.focus_topic,
      title = EXCLUDED.title,
      status = 'draft',
      draft_markdown = EXCLUDED.draft_markdown,
      draft_html = EXCLUDED.draft_html,
      blog_to_listing_link_status = EXCLUDED.blog_to_listing_link_status,
      metadata_json = EXCLUDED.metadata_json,
      updated_at = now()
    `,[t,e,i,a.type,a.focusTopic,a.title,a.draftMarkdown,a.draftHtml,a.blogToListingStatus,JSON.stringify(a.metadata)])}async function y(t,e,i,a){await (0,r.query)(`
    UPDATE directoryiq_authority_posts
    SET
      featured_image_prompt = $4,
      featured_image_url = $5,
      updated_at = now()
    WHERE user_id = $1 AND listing_source_id = $2 AND slot_index = $3
    `,[t,e,i,a.imagePrompt,a.imageUrl])}async function v(t,e,i,a){await (0,r.query)(`
    UPDATE directoryiq_authority_posts
    SET
      status = 'published',
      published_post_id = $4,
      published_url = $5,
      blog_to_listing_link_status = $6,
      listing_to_blog_link_status = $7,
      metadata_json = $8::jsonb,
      updated_at = now()
    WHERE user_id = $1 AND listing_source_id = $2 AND slot_index = $3
    `,[t,e,i,a.publishedPostId,a.publishedUrl,a.blogToListingStatus,a.listingToBlogStatus,JSON.stringify(a.metadata)])}async function E(t,e){return(await (0,r.query)(`
    INSERT INTO directoryiq_versions
    (user_id, listing_source_id, authority_post_id, action_type, version_label, score_snapshot_json, content_delta_json, link_delta_json)
    VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8::jsonb)
    RETURNING id
    `,[t,e.listingId,e.authorityPostId??null,e.actionType,e.versionLabel,JSON.stringify(e.scoreSnapshot),JSON.stringify(e.contentDelta),JSON.stringify(e.linkDelta)]))[0].id}[r,a]=s.then?(await s)():s,t.s(["addDirectoryIqVersion",()=>E,"getAllListingsWithEvaluations",()=>h,"getAuthorityPostBySlot",()=>g,"getDirectoryIqSettings",()=>c,"getListingEvaluation",()=>m,"markPostPublished",()=>v,"saveAuthorityImage",()=>y,"upsertAuthorityPostDraft",()=>f]),i()}catch(t){i(t)}},!1),42540,t=>{"use strict";function e(t){if(!t)return null;let e=t.trim();return e.length>0?e:null}function i(t){let i=e(t);if(!i)return null;try{let t=new URL(i);if("http:"!==t.protocol&&"https:"!==t.protocol)return null;return t.toString()}catch{return null}}function r(t,e){try{let i=e.startsWith("/")?e:`/${e.replace(/^\/+/,"")}`;return new URL(i,t).toString()}catch{return null}}function a(t){let a=e(t.rawUrl);if(!a)return null;if(/^https?:\/\//i.test(a))return a;if(a.startsWith("//"))return`https:${a}`;let n=i(t.listingUrl),s=i(t.bdBaseUrl),o=n??s;return o?(a.startsWith("/")||!a.includes("/"),r(o,a)):null}t.s(["normalizeListingImageUrl",()=>a])},17278,t=>t.a(async(e,i)=>{try{var r=t.i(89171),a=t.i(23203),n=t.i(28239),s=t.i(28248),o=t.i(42540),l=e([a,n,s]);function u(t){for(let e of t)if("string"==typeof e&&e.trim().length>0)return e.trim();return null}async function d(t,{params:e}){try{var i;let l=(0,a.resolveUserId)(t);await (0,a.ensureUser)(l);let{listingId:d}=await Promise.resolve(e),c=await (0,n.getListingEvaluation)(l,decodeURIComponent(d)),_=await (0,s.getDirectoryIqIntegration)(l,"brilliant_directories"),p=await (0,s.getDirectoryIqIntegration)(l,"openai"),g=(i=_.meta,u([i.baseUrl,i.base_url,process.env.DIRECTORYIQ_BD_BASE_URL]));if(!c.listing||!c.evaluation){if("1"===process.env.E2E_MOCK_BD||"1"===process.env.E2E_TEST_MODE)return r.NextResponse.json({listing:{listing_id:decodeURIComponent(d),listing_name:decodeURIComponent(d),listing_url:null,mainImageUrl:null},evaluation:{totalScore:0},authority_posts:[],settings:{},integrations:{brilliant_directories:!0,openai:!0}});return r.NextResponse.json({error:"Listing not found"},{status:404})}let h=function(t,e,i){let r=t??{},a=(Array.isArray(r.gallery)?r.gallery:[])[0],n=(Array.isArray(r.users_portfolio)?r.users_portfolio:[])[0],s="string"==typeof a?a:a&&"object"==typeof a?u([a.url,a.src,a.image,a.image_url]):null,l="string"==typeof n?n:n&&"object"==typeof n?u([n.file_main_full_url,n.file_thumbnail_full_url,n.original_image_url,n.url,n.src,n.image,n.image_url,n.file]):null;for(let t of[{field:"users_portfolio[0]",value:l},{field:"primary_image",value:r.primary_image},{field:"featured_image",value:r.featured_image},{field:"image_url",value:r.image_url},{field:"photo",value:r.photo},{field:"logo",value:r.logo},{field:"thumbnail",value:r.thumbnail},{field:"image",value:r.image},{field:"cover_image",value:r.cover_image},{field:"imageUrl",value:r.imageUrl},{field:"gallery[0]",value:s}]){let r=u([t.value]);if(!r)continue;let a=(0,o.normalizeListingImageUrl)({rawUrl:r,listingUrl:e,bdBaseUrl:i});if(a)return{mainImageUrl:a,sourceField:t.field,rawValue:r}}return{mainImageUrl:null,sourceField:null,rawValue:u([r.primary_image,r.featured_image,r.image_url,r.photo,r.logo,r.thumbnail,r.image,r.cover_image,r.imageUrl,l,s])}}(c.listing.raw_json,c.listing.url,g);return r.NextResponse.json({listing:{listing_id:c.listing.source_id,listing_name:c.listing.title??c.listing.source_id,listing_url:c.listing.url,mainImageUrl:h.mainImageUrl},evaluation:c.evaluation,authority_posts:c.authorityPosts.map(t=>({id:t.id,slot:t.slot_index,type:t.post_type,title:t.title,focus_topic:t.focus_topic,status:t.status,blog_to_listing_status:t.blog_to_listing_link_status,listing_to_blog_status:t.listing_to_blog_link_status,featured_image_url:t.featured_image_url,published_url:t.published_url,updated_at:t.updated_at})),settings:c.settings,integrations:{brilliant_directories:"connected"===_.status,openai:"connected"===p.status||!!process.env.OPENAI_API_KEY}})}catch(e){let t=e instanceof Error?e.message:"Unknown listing detail error";return r.NextResponse.json({error:t},{status:500})}}[a,n,s]=l.then?(await l)():l,t.s(["GET",()=>d,"runtime",0,"nodejs"]),i()}catch(t){i(t)}},!1),75047,t=>t.a(async(e,i)=>{try{var r=t.i(47909),a=t.i(74017),n=t.i(96250),s=t.i(59756),o=t.i(61916),l=t.i(74677),u=t.i(69741),d=t.i(16795),c=t.i(87718),_=t.i(95169),p=t.i(47587),g=t.i(66012),h=t.i(70101),m=t.i(26937),f=t.i(10372),y=t.i(93695);t.i(52474);var v=t.i(220),E=t.i(17278),b=e([E]);[E]=b.then?(await b)():b;let x=new r.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/directoryiq/listings/[listingId]/route",pathname:"/api/directoryiq/listings/[listingId]",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/directoryiq/listings/[listingId]/route.ts",nextConfigOutput:"",userland:E}),{workAsyncStorage:S,workUnitAsyncStorage:T,serverHooks:N}=x;function R(){return(0,n.patchFetch)({workAsyncStorage:S,workUnitAsyncStorage:T})}async function w(t,e,i){x.isDev&&(0,s.addRequestMeta)(t,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/directoryiq/listings/[listingId]/route";r=r.replace(/\/index$/,"")||"/";let n=await x.prepare(t,e,{srcPage:r,multiZoneDraftMode:!1});if(!n)return e.statusCode=400,e.end("Bad Request"),null==i.waitUntil||i.waitUntil.call(i,Promise.resolve()),null;let{buildId:E,params:b,nextConfig:R,parsedUrl:w,isDraftMode:S,prerenderManifest:T,routerServerContext:N,isOnDemandRevalidate:A,revalidateOnlyGenerated:C,resolvedPathname:I,clientReferenceManifest:k,serverActionsManifest:$}=n,D=(0,u.normalizeAppPath)(r),O=!!(T.dynamicRoutes[D]||T.routes[I]),U=async()=>((null==N?void 0:N.render404)?await N.render404(t,e,w,!1):e.end("This page could not be found"),null);if(O&&!S){let t=!!T.routes[I],e=T.dynamicRoutes[D];if(e&&!1===e.fallback&&!t){if(R.experimental.adapterPath)return await U();throw new y.NoFallbackError}}let q=null;!O||x.isDev||S||(q=I,q="/index"===q?"/":q);let L=!0===x.isDev||!O,j=O&&!L;$&&k&&(0,l.setManifestsSingleton)({page:r,clientReferenceManifest:k,serverActionsManifest:$});let P=t.method||"GET",M=(0,o.getTracer)(),H=M.getActiveScopeSpan(),F={params:b,prerenderManifest:T,renderOpts:{experimental:{authInterrupts:!!R.experimental.authInterrupts},cacheComponents:!!R.cacheComponents,supportsDynamicResponse:L,incrementalCache:(0,s.getRequestMeta)(t,"incrementalCache"),cacheLifeProfiles:R.cacheLife,waitUntil:i.waitUntil,onClose:t=>{e.on("close",t)},onAfterTaskError:void 0,onInstrumentationRequestError:(e,i,r,a)=>x.onRequestError(t,e,r,a,N)},sharedContext:{buildId:E}},B=new d.NodeNextRequest(t),W=new d.NodeNextResponse(e),K=c.NextRequestAdapter.fromNodeNextRequest(B,(0,c.signalFromNodeResponse)(e));try{let n=async t=>x.handle(K,F).finally(()=>{if(!t)return;t.setAttributes({"http.status_code":e.statusCode,"next.rsc":!1});let i=M.getRootSpanAttributes();if(!i)return;if(i.get("next.span_type")!==_.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${i.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=i.get("next.route");if(a){let e=`${P} ${a}`;t.setAttributes({"next.route":a,"http.route":a,"next.span_name":e}),t.updateName(e)}else t.updateName(`${P} ${r}`)}),l=!!(0,s.getRequestMeta)(t,"minimalMode"),u=async s=>{var o,u;let d=async({previousCacheEntry:a})=>{try{if(!l&&A&&C&&!a)return e.statusCode=404,e.setHeader("x-nextjs-cache","REVALIDATED"),e.end("This page could not be found"),null;let r=await n(s);t.fetchMetrics=F.renderOpts.fetchMetrics;let o=F.renderOpts.pendingWaitUntil;o&&i.waitUntil&&(i.waitUntil(o),o=void 0);let u=F.renderOpts.collectedTags;if(!O)return await (0,g.sendResponse)(B,W,r,F.renderOpts.pendingWaitUntil),null;{let t=await r.blob(),e=(0,h.toNodeOutgoingHttpHeaders)(r.headers);u&&(e[f.NEXT_CACHE_TAGS_HEADER]=u),!e["content-type"]&&t.type&&(e["content-type"]=t.type);let i=void 0!==F.renderOpts.collectedRevalidate&&!(F.renderOpts.collectedRevalidate>=f.INFINITE_CACHE)&&F.renderOpts.collectedRevalidate,a=void 0===F.renderOpts.collectedExpire||F.renderOpts.collectedExpire>=f.INFINITE_CACHE?void 0:F.renderOpts.collectedExpire;return{value:{kind:v.CachedRouteKind.APP_ROUTE,status:r.status,body:Buffer.from(await t.arrayBuffer()),headers:e},cacheControl:{revalidate:i,expire:a}}}}catch(e){throw(null==a?void 0:a.isStale)&&await x.onRequestError(t,e,{routerKind:"App Router",routePath:r,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:j,isOnDemandRevalidate:A})},!1,N),e}},c=await x.handleResponse({req:t,nextConfig:R,cacheKey:q,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:T,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:C,responseGenerator:d,waitUntil:i.waitUntil,isMinimalMode:l});if(!O)return null;if((null==c||null==(o=c.value)?void 0:o.kind)!==v.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==c||null==(u=c.value)?void 0:u.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});l||e.setHeader("x-nextjs-cache",A?"REVALIDATED":c.isMiss?"MISS":c.isStale?"STALE":"HIT"),S&&e.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let _=(0,h.fromNodeOutgoingHttpHeaders)(c.value.headers);return l&&O||_.delete(f.NEXT_CACHE_TAGS_HEADER),!c.cacheControl||e.getHeader("Cache-Control")||_.get("Cache-Control")||_.set("Cache-Control",(0,m.getCacheControlHeader)(c.cacheControl)),await (0,g.sendResponse)(B,W,new Response(c.value.body,{headers:_,status:c.value.status||200})),null};H?await u(H):await M.withPropagatedContext(t.headers,()=>M.trace(_.BaseServerSpan.handleRequest,{spanName:`${P} ${r}`,kind:o.SpanKind.SERVER,attributes:{"http.method":P,"http.target":t.url}},u))}catch(e){if(e instanceof y.NoFallbackError||await x.onRequestError(t,e,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:j,isOnDemandRevalidate:A})},!1,N),O)throw e;return await (0,g.sendResponse)(B,W,new Response(null,{status:500})),null}}t.s(["handler",()=>w,"patchFetch",()=>R,"routeModule",()=>x,"serverHooks",()=>N,"workAsyncStorage",()=>S,"workUnitAsyncStorage",()=>T]),i()}catch(t){i(t)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__fc1780b6._.js.map