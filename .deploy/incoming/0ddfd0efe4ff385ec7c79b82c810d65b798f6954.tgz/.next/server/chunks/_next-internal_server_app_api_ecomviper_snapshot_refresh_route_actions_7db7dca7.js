module.exports=[37171,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ecomviper_snapshot_refresh_route_actions_7db7dca7.js.map