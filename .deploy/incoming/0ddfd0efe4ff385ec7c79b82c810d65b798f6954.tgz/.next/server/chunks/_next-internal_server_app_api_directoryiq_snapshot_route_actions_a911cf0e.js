module.exports=[34099,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_directoryiq_snapshot_route_actions_a911cf0e.js.map