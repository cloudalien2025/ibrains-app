module.exports=[61799,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_brains_%5Bid%5D_route_actions_f333e81f.js.map