module.exports=[35804,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ssc_storyboard_asset_route_actions_fb00823c.js.map