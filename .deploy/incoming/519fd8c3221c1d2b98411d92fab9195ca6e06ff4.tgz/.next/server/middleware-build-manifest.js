globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a9ed074e89b16a5e.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/b8d5ea025cfb2ec4.js",
    "static/chunks/f2f58a7e93290fbb.js",
    "static/chunks/turbopack-6b8fc8284e1e638e.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];