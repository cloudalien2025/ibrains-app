:HL["/_next/static/chunks/a5646ef69d5ce816.css","style"]
0:{"buildId":"ctikoly049VYmLt7XlD3x","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
