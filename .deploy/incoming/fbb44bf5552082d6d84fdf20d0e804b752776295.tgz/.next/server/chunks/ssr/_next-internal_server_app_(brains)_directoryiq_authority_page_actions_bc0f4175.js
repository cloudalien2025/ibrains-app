module.exports=[31594,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28brains%29_directoryiq_authority_page_actions_bc0f4175.js.map