module.exports=[7642,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)("div",{className:"min-h-screen",children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_%28brains%29_layout_tsx_118ec4ba._.js.map