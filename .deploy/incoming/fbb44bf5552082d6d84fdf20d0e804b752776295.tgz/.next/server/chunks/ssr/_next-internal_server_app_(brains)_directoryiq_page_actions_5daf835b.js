module.exports=[38352,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28brains%29_directoryiq_page_actions_5daf835b.js.map