module.exports=[31077,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28brains%29_directoryiq_authority_blogs_page_actions_c3257fc8.js.map