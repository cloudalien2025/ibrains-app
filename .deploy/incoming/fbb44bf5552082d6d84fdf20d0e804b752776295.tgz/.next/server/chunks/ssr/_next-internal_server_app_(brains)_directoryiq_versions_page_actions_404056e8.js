module.exports=[76145,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28brains%29_directoryiq_versions_page_actions_404056e8.js.map