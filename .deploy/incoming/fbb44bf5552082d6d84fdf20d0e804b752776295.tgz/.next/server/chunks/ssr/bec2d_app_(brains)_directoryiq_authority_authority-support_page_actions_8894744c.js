module.exports=[93755,(a,b,c)=>{}];

//# sourceMappingURL=bec2d_app_%28brains%29_directoryiq_authority_authority-support_page_actions_8894744c.js.map